import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useGetLoginUserMutation } from "../../component/redux/registerapi";
import ReCAPTCHA from "react-google-recaptcha";
import user from "../../assets/images/user.png";
import lock from "../../assets/images/lock.png";
import login_bg from "../../assets/images/login_bg.png";
import { ToastContainer,toast } from 'react-toastify'

const validationSchema = yup.object().shape({
    email: yup
        .string()
        .required("Email is required!")
        .email("Email is invalid!")
        .matches(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/, 'Enter valid email')
        .trim(),
    password: yup.string().required('Password is required')
        .matches(/[A-Z]/, 'Please Give One or More UpperCase Letters')
        .matches(/[0-9]/, 'Please One or More Numbers')
        .matches(/[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/, 'Please Give One or More Special Characters')
        .min(8, 'Password must be at least 8 characters')
        .max(15, 'Password msut be less than 15 Characters')
        .trim(),
    rememberme: yup.bool().oneOf([true], 'Rememberme is required'),



});

const Loginpage = () => {
    const navigate = useNavigate()
    const [Captcha, setCaptcha] = useState(false)
    const myStyle = {
        borderLeft: "1px solid",
        paddingLeft: "10px",
    }


    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(validationSchema),
        mode: "onBlur",
    });

    
    function onChange(value) {
        console.log("Captcha value:", value);
        setCaptcha(true)
    }

    const [LoginUser] = useGetLoginUserMutation()

    const onSubmit = async (data) => {
        try {
            console.log(data);
            const response = await LoginUser(data);
            if (response.error) {
                const otperrorMessage = response.error.data.message
                toast.error(otperrorMessage, {
                    position: toast.POSITION.TOP_CENTER
                })
            } else {
                console.log(response);
                const otpMsg = response.data.updateOtpData.otp.code
                console.log(otpMsg);
                const getUserID = response.data.updateOtpData._id
                localStorage.setItem('userId', getUserID)
                // const token = response.data.token
                // localStorage.setItem('LoggedUserToken',JSON.stringify(token))
                toast.info(`Your OTP ${otpMsg}`, {
                    position: toast.POSITION.TOP_CENTER,
                    autoClose: 10000,
                    closeOnClick: true
                });
                navigate('/loginotp')

            }

        }
        catch (error) {
            console.log(error)
            toast.error("Invalid Login")
        }

    }

    return (
        <div className="maincontent">
            <div className='toast-container'>
                <ToastContainer limit={1} />
            </div>
            <div className="pageContent">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="card mycard">
                                <div className="card-body p-md-5 p-3">
                                    <div className="row justify-content-center">
                                        <div className="col-lg-6 col-md-8 col-sm-10">
                                            <div className="text-center fs-36 fw-700 mb-4">Login</div>
                                            <form onSubmit={handleSubmit(onSubmit)}>
                                                <div className="form-group formInputs mb-4">
                                                    <div className="input-group iconinput">
                                                        <div className="input-group-prepend">
                                                            <span className="input-group-text">
                                                                <img alt="" src={user} />
                                                            </span>
                                                        </div>
                                                        <input
                                                            // className="form-control py-0"
                                                            type="text"
                                                            name=""
                                                            placeholder="Enter Your email id"
                                                            {...register("email")}
                                                            className={`form-control ${errors.email ? "is-invalid" : ""
                                                                }`}
                                                        />
                                                        <div className="invalid-feedback">
                                                            {errors.email?.message}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-group formInputs mb-4">
                                                    <div className="input-group iconinput">
                                                        <div className="input-group-prepend">
                                                            <span className="input-group-text">
                                                                <img alt="" src={lock} />
                                                            </span>
                                                        </div>
                                                        <input
                                                            // className="form-control py-0"
                                                            type="password"
                                                            name=""
                                                            placeholder="Enter Your Password"
                                                            {...register("password")}
                                                            className={`form-control ${errors.password ? "is-invalid" : ""
                                                                }`}
                                                        />
                                                        <div className="invalid-feedback">
                                                            {errors.password?.message}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="mb-5">
                                                    <div className="custom-control custom-checkbox custom-control-inline custom_checkbox">

                                                        <input
                                                            type="checkbox"
                                                            className={`custom-control-input  ${errors?.rememberme ? 'is-invalid' : ''}`}
                                                            id="customCheck"
                                                            {...register('rememberme')}
                                                            name="rememberme" />
                                                        <label
                                                            className="custom-control-label"
                                                            for="customCheck"
                                                        >
                                                            Remember me
                                                        </label>
                                                        <div className="invalid-feedback">
                                                            <span style={{ margin: "13px" }}>{errors?.rememberme?.message}</span>
                                                        </div>
                                                    </div>
                                                    <Link
                                                        to="/forgetpassword"
                                                        className="d-inline-block text-gray2"
                                                        style={myStyle}
                                                    >
                                                        Forgot password ?
                                                    </Link>
                                                </div>


                                                <ReCAPTCHA
                                                    sitekey="6LeuDyslAAAAAMK4d4FlhjytwNlAdG-D9X4LjL_E "
                                                    onChange={onChange}
                                                />
                                                <br />

                                                <div className="text-center mb-4">
                                                    {!Captcha ? <button
                                                        className="btn btn-primary fs-16 fw-400"
                                                        type="submit"
                                                        disabled
                                                    >
                                                        Login
                                                    </button>:<button
                                                        className="btn btn-primary fs-16 fw-400"
                                                        type="submit"
                                                    >
                                                        Login
                                                    </button> }
                                                </div>
                                                <div className="text-gray2 text-center fs-15 fw-600">
                                                    Not a member ?{" "}
                                                    <Link
                                                        to="/register"
                                                        className="d-inline-block fw-700 text-primary"
                                                    >
                                                        Create Account
                                                    </Link>
                                                </div>
                                            </form>
                                        </div>
                                        <div className="col-lg-6 text-center d-none d-lg-block">
                                            <img alt="" src={login_bg} className="img-fluid" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default Loginpage;





//import React from 'react';
// import { Link } from 'react-router-dom';
// import { useForm } from 'react-hook-form';
// import { yupResolver } from '@hookform/resolvers/yup';
// import * as Yup from 'yup';
// import { useGetLoginUserQuery } from '../../component/redux/registerapi'
// import { useNavigate } from 'react-router-dom';
// import user from '../../assets/images/user.png'
// import lock from '../../assets/images/lock.png'
// import login_bg from '../../assets/images/login_bg.png'
// import { toast } from 'react-toastify';

// const schema = Yup.object().shape({
//     email: Yup.string().required('Email is required').email('Email is invalid')
//         .matches(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/, 'Enter valid email')
//     ,
//     password: Yup.string().required('Password is required').matches(/[A-Z]/, 'Please Give One or More UpperCase Letters').matches(/[0-9]/, 'Please One or More Numbers').matches(/[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/, 'Please Give One or More Special Characters').trim().min(8, 'Password must be at least 8 characters'),
//  });

// const Loginpage = () => {
//     const navigate = useNavigate();
//     const [loginUser] = useGetLoginUserQuery()



//     const { register, handleSubmit, formState: { errors }, reset } = useForm({
//         resolver: yupResolver(schema),
//         mode: 'all'

//     });
//     const LoginUser = async (data) => {
//         try {
//             const response = await loginUser(data)
//             if (response.error) {
//                 const otperrorMessage = response.error.data.message
//                 toast.error(otperrorMessage, {
//                     position: toast.POSITION.TOP_CENTER
//                 })
//             } else {
//                 const otpMsg = response.data.data.otp.code
//                 console.log(otpMsg);
//                 const getUserID = response.data.data._id
//                 localStorage.setItem('userId', getUserID)
//                 toast.info(`Your OTP ${otpMsg}`, {
//                     position: toast.POSITION.TOP_CENTER,
//                     autoClose: 10000,
//                     closeOnClick: true
//                 });
//                 navigate('/registerotp')

//             }
//         } catch (err) {
//             console.log(err.message)
//             toast.error('SomeThing Went Wrong', {
//                 position: toast.POSITION.TOP_CENTER
//             })
//         }

//     }

//     const myStyle = {
//         borderLeft: "1px solid",
//         paddingLeft: "10px",
//     }
//     return (
//         <div className="maincontent">
//             <div className="pageContent">
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12">
//                             <div className="card mycard">
//                                 <div className="card-body p-md-5 p-3">
//                                     <div className="row justify-content-center">
//                                         <div className="col-lg-6 col-md-8 col-sm-10">
//                                             <div className="text-center fs-36 fw-700 mb-4">Login</div>
//                                             <form onSubmit={handleSubmit(LoginUser)}>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={user} />
//                                                             </span>
//                                                         </div>
//                                                         <input
//                                                             className={`form-control  ${errors?.email ? 'is-invalid' : ''}`}
//                                                             type="text"
//                                                             name="email"
//                                                             {...register('email')}
//                                                             placeholder="Enter Your Email Id" />
//                                                         <div className="invalid-feedback ">
//                                                             <span style={{ margin: "13px" }}>{errors?.email?.message}</span>
//                                                         </div>                                                </div>
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={lock} />
//                                                             </span>
//                                                         </div>
//                                                         <input
//                                                             className={`form-control  ${errors?.password ? 'is-invalid' : ''}`}
//                                                             type="password"
//                                                             name="password"
//                                                             {...register('password')}
//                                                             placeholder="Enter Your Password" />
//                                                         <div className="invalid-feedback ">
//                                                             <span style={{ margin: "13px" }}>{errors?.password?.message}</span>
//                                                         </div>                                                    </div>
//                                                 </div>
//                                                 <div className="mb-5">
//                                                     <div className="custom-control custom-checkbox custom-control-inline custom_checkbox">
//                                                         <input type="checkbox" className="custom-control-input" id="customCheck" name="example1" />
//                                                         <label className="custom-control-label" for="customCheck">Remember me</label>
//                                                     </div>
//                                                     <Link to="/forgetpassword" className="d-inline-block text-gray2" style={myStyle}>Forgot password ?</Link>
//                                                 </div>
//                                                 <div className="text-center mb-4">
//                                                     <button className="btn btn-primary fs-16 fw-400" type="button">Login</button>
//                                                 </div>
//                                             </form>
//                                             <div className="text-gray2 text-center fs-15 fw-600">Not a member ? <Link to="/register" className="d-inline-block fw-700 text-primary">Create Account</Link></div>
//                                         </div>
//                                         <div className="col-lg-6 text-center d-none d-lg-block">
//                                             <img alt="" src={login_bg} className="img-fluid" />
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     )
// }

// export default Loginpage;



// import React from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import { useForm } from 'react-hook-form';
// import { yupResolver } from '@hookform/resolvers/yup';
// import * as Yup from 'yup';
// import user from '../../assets/images/user.png';
// import lock from '../../assets/images/lock.png';
// import login_bg from '../../assets/images/login_bg.png';
// import { useGetLoginUserQuery } from '../../component/redux/registerapi';
// import { toast } from 'react-toastify';

// const schema = Yup.object().shape({
//     email: Yup.string().required('Email is required').email('Email is invalid')
//         .matches(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/, 'Enter valid email')
//     ,
//     password: Yup.string().required('Password is required').matches(/[A-Z]/, 'Please Give One or More UpperCase Letters').matches(/[0-9]/, 'Please One or More Numbers').matches(/[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/, 'Please Give One or More Special Characters').trim().min(8, 'Password must be at least 8 characters'),
//     rememberme: Yup.bool().oneOf([true], 'Accept Terms & Conditions is required'),

// })

// const Loginpage = () => {
//     const navigate = useNavigate();
//     const [loginUser] = useGetLoginUserQuery();
//     const { register, handleSubmit, formState: { errors }, reset } = useForm({
//         resolver: yupResolver(schema),
//         mode: 'all'

//     });

//     const onSubmit = async (data) => {

//         try {
//             console.log(data);
//             const response = await loginUser(data)
//             if (response.error) {
//                 const otperrorMessage = response.error.data.message;
//                 toast.error(otperrorMessage, {
//                     position: toast.POSITION.TOP_CENTER
//                 })
//             } else {
//                 const otpMsg = response.data.data.otp.code
//                 console.log(otpMsg);
//                 const getUserID = response.data.data._id
//                 localStorage.setItem('userId', getUserID)
//                 toast.info(`Your OTP ${otpMsg}`, {
//                     position: toast.POSITION.TOP_CENTER,
//                     autoClose: 10000,
//                     closeOnClick: true
//                 });
//                 navigate('/loginotp')
//             }
//         } catch (err) {
//             console.log(err);
//         }
//     };

//     const myStyle = {
//         borderLeft: '1px solid',
//         paddingLeft: '10px',
//     };

//     return (
//         <div className="maincontent">
//             <div className="pageContent">
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12">
//                             <div className="card mycard">
//                                 <div className="card-body p-md-5 p-3">
//                                     <div className="row justify-content-center">
//                                         <div className="col-lg-6 col-md-8 col-sm-10">
//                                             <form onSubmit={handleSubmit(onSubmit)}>
//                                                 <div className="text-center fs-36 fw-700 mb-4">Login</div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={user} />
//                                                             </span>
//                                                         </div>
//                                                         <input
//                                                             className={`form-control  ${errors?.email ? 'is-invalid' : ''}`}
//                                                             type="text"
//                                                             name="email"
//                                                             {...register('email')}
//                                                             placeholder="Enter Your Email Id" />
//                                                         <div className="invalid-feedback ">
//                                                             <span style={{ margin: "13px" }}>{errors?.email?.message}</span>
//                                                         </div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={lock} />
//                                                             </span>
//                                                         </div>
//                                                         <input
//                                                             className={`form-control  ${errors?.password ? 'is-invalid' : ''}`}
//                                                             type="password"
//                                                             name="password"
//                                                             {...register('password')}
//                                                             placeholder="Enter Your Password" />
//                                                         <div className="invalid-feedback ">
//                                                             <span style={{ margin: "13px" }}>{errors?.password?.message}</span>
//                                                         </div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="mb-5">
//                                                     <div className="custom-control custom-checkbox custom-control-inline custom_checkbox">
//                                                         <input
//                                                             type="checkbox"
//                                                             className={`custom-control-input  ${errors?.rememberme ? 'is-invalid' : ''}`}
//                                                             id="customCheck"
//                                                             {...register('rememberme')}
//                                                             name="rememberme" />
//                                                         <label
//                                                             className="custom-control-label"
//                                                             htmlFor="customCheck"
//                                                         >
//                                                             Remember me
//                                                         </label>
//                                                     </div>
//                                                     <div className="invalid-feedback ">
//                                                         <span style={{ margin: "13px" }}>{errors?.rememberme?.message}</span>
//                                                     </div>
//                                                     <Link
//                                                         to="/forgetpassword"
//                                                         className="d-inline-block text-gray2"
//                                                         style={myStyle}
//                                                     >
//                                                         Forgot password ?
//                                                     </Link>
//                                                 </div>
//                                                 <div className="text-center mb-4">
//                                                     <button
//                                                         className="btn btn-primary fs-16 fw-400"
//                                                         type="submit"
//                                                     >
//                                                         Login
//                                                     </button>
//                                                 </div>
//                                                 <div className="text-gray2 text-center fs-15 fw-600">
//                                                     Not a member ?{' '}
//                                                     <Link
//                                                         to="/register"
//                                                         className="d-inline-block fw-700 text-primary"
//                                                     >
//                                                         Create Account
//                                                     </Link>
//                                                 </div>
//                                             </form>
//                                         </div>
//                                         <div className="col-lg-6 text-center d-none d-lg-block">
//                                             <img alt="" src={login_bg} className="img-fluid" />
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default Loginpage;

