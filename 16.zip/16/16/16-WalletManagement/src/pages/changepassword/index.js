import React from 'react';


import locked_Img from '../../assets/images/locked_Img.png'
import lock from '../../assets/images/lock.png'
// import message from '../../assets/images/message.png'

const Changepassword = () => {
    return ( 
        <div className="maincontent">
        <div className="pageContent">
            <div className="container">
                <div className="row">
                    <div className="col-lg-12">
                        <div className="card mycard">
                            <div className="card-body p-md-5 p-3">
                                    <div className="row justify-content-center align-items-center">
                                        <div className="col-lg-6 col-md-8 col-sm-10">
                                            
                                            <div className="row justify-content-center">
                                                <div className="col-lg-10">
                                                        <div className="text-left fs-36 fw-600 mb-4">Reset Password</div>
                                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={lock} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="password" name="" placeholder="Enter current Password" />
                                            </div>
                                        </div>
                                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={lock} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="password" name="" placeholder="Enter New Password" />
                                            </div>
                                        </div>
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={lock} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="password" name="" placeholder="Enter New Confirm Password" />
                                            </div>
                                        </div>
                                                        {/* <div className="form-group formInputs mb-5">
                                                                <div className="input-group iconinput">
                                                                    <div className="input-group-prepend">
                                                                        <span className="input-group-text">
                                                                            <img alt="" src={message} />
                                                                        </span>
                                                                    </div>
                                                                    <input className="form-control py-0" type="text" name="" placeholder="Enter Your Email Id" />
                                                                </div>
                                                        </div> */}
                                                </div>
                                            </div>                                               
                                            
                                            <div className="text-center mb-4">
                                                <button className="btn btn-primary fs-16 fw-400" type="button">Send</button>
                                            </div>
                                            
                                        </div>
                                        <div className="col-lg-6 text-center d-none d-lg-block">
                                            <img alt="" src={locked_Img} className="img-fluid" />
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
     );
}
 
export default Changepassword;