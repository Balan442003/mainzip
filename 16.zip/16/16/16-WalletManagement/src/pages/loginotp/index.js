import React from 'react';
import locked_Img from '../../assets/images/locked_Img.png'
import message from '../../assets/images/message.png'
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { useLoginVerifyOtpMutation } from '../../component/redux/registerapi';
import { toast } from 'react-toastify';

// schema OTP validation
const schema = Yup.object().shape({
    otp: Yup.string().required('otp is required').min(6, 'Enter Six Digits Number').max(6, 'Invalid OTP').trim(),
});

const LoginOtpPage = () => {
    const navigate = useNavigate()
    const userId = localStorage.getItem('userId')
    const { register, handleSubmit, formState: { errors }, reset } = useForm({
        resolver: yupResolver(schema),
        mode: 'all'
    });
    const [verifyOtp] = useLoginVerifyOtpMutation()
    const onSubmit = async (data) => {
        console.log(data);
        try {
            const verifyotpNumber = await verifyOtp({ otp: data.otp, id: userId})
            console.log(verifyotpNumber);
            if (verifyotpNumber.error) {
                const errorMessage = verifyotpNumber.error.data.message
                toast.error(errorMessage, {
                    position: toast.POSITION.TOP_CENTER
                })
                return
            }
            toast.success(verifyotpNumber.data.message, {
                position: toast.POSITION.TOP_CENTER
            })
            const token = verifyotpNumber.data.token
            localStorage.setItem('token',token)
            localStorage.removeItem('userId')
            console.log(userId);
            localStorage.setItem('verifyUserId',userId)
            navigate('/Dashboard')
        } catch (err) {
            console.log(err.message);
        }
    }
    return (
        <div className="maincontent">
            <div className="pageContent">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="card mycard">
                                <div className="card-body p-md-5 p-3">
                                    <div className="row justify-content-center align-items-center">
                                        <div className="col-lg-6 col-md-8 col-sm-10">

                                            <div className="row justify-content-center">
                                                <div className="col-lg-10">
                                                    <div className="text-left fs-36 fw-600 mb-4">Enter Your OTP</div>
                                                    <form onSubmit={handleSubmit(onSubmit)}>
                                                        <div className="form-group formInputs mb-5">
                                                            <div className="input-group iconinput">
                                                                <div className="input-group-prepend">
                                                                    <span className="input-group-text">
                                                                        <img alt="" src={message} />
                                                                    </span>
                                                                </div>
                                                                <input
                                                                    className={`form-control  ${errors?.otp ? 'is-invalid' : ''
                                                                        }`}
                                                                    type="text"
                                                                    name="otp"
                                                                    {...register('otp')}
                                                                    placeholder="Enter Your OTP" />
                                                                <div className="invalid-feedback ">
                                                                    <span style={{ margin: "13px" }}>{errors?.otp?.message}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="text-center mb-4">
                                                            <button className="btn btn-primary fs-16 fw-400" type="submit">Send</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>




                                        </div>
                                        <div className="col-lg-6 text-center d-none d-lg-block">
                                            <img alt="" src={locked_Img} className="img-fluid" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default LoginOtpPage;

