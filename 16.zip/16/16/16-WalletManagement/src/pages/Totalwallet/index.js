import React, { useState } from 'react';


import walletsm from '../../assets/images/wallet_sm.png';
import icon1 from '../../assets/images/icon1.png';
import withdraw_sm from '../../assets/images/withdraw_sm.png';
import icon2 from '../../assets/images/icon2.png';
import icon3 from '../../assets/images/icon3.png';
import icon4 from '../../assets/images/icon4.png';
import icon5 from '../../assets/images/icon5.png';
import icon6 from '../../assets/images/icon6.png';
import icon7 from '../../assets/images/icon7.png';
import icon8 from '../../assets/images/icon8.png';
import icon9 from '../../assets/images/icon9.png';
import icon10 from '../../assets/images/icon10.png';
import icon11 from '../../assets/images/icon11.png';
import btc_64 from '../../assets/images/btc_64.png';
import qr_code from '../../assets/images/qr_code.png';
import copyIcon from '../../assets/images/copyIcon.png';

const TotalWalletAmt = () => {
    const [isActive, setIsActive] = useState(false);

    const rightsideOpen = () => {
        setIsActive(current => !current)
    }
     const closeRSide = () => {
        setIsActive(current => !current)
    }
    
    return ( 
        <>
            <div className="maincontent homepage">
                <div className="pageContent">
                    <div className="container mb-5">
                        <div className="row justify-content-center">
                            <div className="col-lg-12">
                                <div className="fs-36 fw-600 text-color text-center mb-4">Total Wallet Amount</div>

                                <div className="row justify-content-center mb-5">
                                    <div className="col-lg-7">
                                        <div className="card mycard border-radius-20">
                                            <div className="card-body p-4">
                                                <div className="row form-row justify-content-between align-items-center py-3">
                                                    <div className="col-md-4">
                                                        <div className="fs-26 fw-600">₹ 32,4245.00</div>
                                                    </div>
                                                    <div className="col-md-2">
                                                        <div className="form-group formInputs mb-md-0">
                                                            <select className="form-control">
                                                                <option>INR</option>
                                                                <option>USD</option>
                                                                <option>BTC</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400 mb-3 mb-sm-0 mr-2" type="button" onClick={rightsideOpen}>
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 px-4 fs-14 fw-400 mb-3 mb-sm-0" type="button" onClick={rightsideOpen}>
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="col-12">
                                        <div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon1} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">BTC</div>
                                                                        <div className="text-green fs-14 fw-400">+0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                         <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button" onClick={rightsideOpen}>
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button" onClick={rightsideOpen}>
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon2} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">ETH</div>
                                                                        <div className="text-red fs-14 fw-400">-0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon3} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">BTC</div>
                                                                        <div className="text-green fs-14 fw-400">+0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon4} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">ETH</div>
                                                                        <div className="text-red fs-14 fw-400">-0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon5} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">BTC</div>
                                                                        <div className="text-green fs-14 fw-400">+0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon6} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">ETH</div>
                                                                        <div className="text-red fs-14 fw-400">-0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon7} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">BTC</div>
                                                                        <div className="text-green fs-14 fw-400">+0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon8} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">ETH</div>
                                                                        <div className="text-red fs-14 fw-400">-0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon9} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">BTC</div>
                                                                        <div className="text-green fs-14 fw-400">+0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon10} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">ETH</div>
                                                                        <div className="text-red fs-14 fw-400">-0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="bordercard borhover mb-3">
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="row">
                                                            <div className="col-sm-6">
                                                                <div className="d-flex">
                                                                    <div className="mr-3">
                                                                        <img alt=""src={icon11} className="img-w40" />
                                                                    </div>
                                                                    <div>
                                                                        <div className="fs-16 fw-700">ETH</div>
                                                                        <div className="text-red fs-14 fw-400">-0.7%</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-6 text-center">
                                                                <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                                <div className="fs-16 fw-500">1.526  BTC</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6 text-center">
                                                        <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                            <img alt=""src={walletsm} className="imgicon mr-2" /> Deposit
                                                        </button>
                                                        <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                            <img alt=""src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div  className={`overlaybg ${isActive ? 'overlay_show' : ''}`}  onClick={closeRSide}></div>
<div className={`rightSide ${isActive ? 'RS_open' : ''}`}>
    <div className="content-deposit d-none">
        <div className="d-flex justify-content-between align-items-center mb-3">
            <div className="fs-36 fw-700">Deposit</div>
            <div>
                <a className="alinkIcon fs-24 text-black" href="javascript:void(0);" onClick={closeRSide}>
                    <i className="bi bi-x"></i>
                </a>
            </div>
        </div>    
        <div className="d-flex align-items-center mb-5">
            <div>
                <img alt=""src={btc_64} className="img-w64" />
            </div>
            <div className="ml-4">
                <div className="fs-24 fw-700">BTC Balance</div>
                <div className="fs-13 fw-400 text-lightblue">Bitcoin</div>
            </div>
        </div>
    
        <div className="secondaryborder mb-5">
            <div className="d-flex justify-content-between align-items-center">
                <div className="fs-20 fw-400 text-lightblue">
                    Total Balance
                </div>
                <div>
                    <div className="fs-20 fw-400">
                        24.1236 BTC
                    </div>
                    <div className="fs-13 fw-400 text-lightblue">
                        3,700.96 INR
                    </div>
                </div>
            </div>
        </div>
        <div className="fs-16 fw-600 mb-2">
            Address
        </div>
        <div className="fs-14 fw-400 text-lightblue lh-24 mb-4">
            Only send ETH to this address. Sending any other asset to this address may result in the loss of your deposit!
        </div>
    
        <div className="bordercard borhover py-2">
            <div className="d-flex">
                <div className="fs-14 fw-400">
                    KJ65FJEOW874KUSH11KDA
                </div>
                <div className="ml-auto">
                    <img alt=""src={copyIcon} className="pointer" />
                </div>
            </div>
        </div>
    
        <div className="row justify-content-center">
            <div className="col-lg-6">
                <div className="my-5 text-center">
                    <img alt=""src={qr_code} className="img-fluid" />
                </div>
            </div>
        </div>    
    
        <div className="fs-16 fw-400 text-lightblue">Ethereum deposits are available after 2 network confirmations.</div>
    </div>
    <div className="content-withdraw">
            <div className="d-flex justify-content-between align-items-center mb-3">
                    <div className="fs-36 fw-700">Withdraw</div>
                    <div>
                        <a className="alinkIcon fs-24 text-black" href="javascript:void(0);" onClick={closeRSide}>
                            <i className="bi bi-x"></i>
                        </a>
                    </div>
                </div>    
                <div className="d-flex align-items-center mb-5">
                    <div>
                        <img alt=""src={btc_64} className="img-w64" />
                    </div>
                    <div className="ml-4">
                        <div className="fs-24 fw-700">BTC Balance</div>
                        <div className="fs-13 fw-400 text-lightblue">Bitcoin</div>
                    </div>
                </div>
            
                <div className="secondaryborder mb-5">
                    <div className="d-flex justify-content-between align-items-center">
                        <div className="fs-20 fw-400 text-lightblue">
                            Total Balance
                        </div>
                        <div>
                            <div className="fs-20 fw-400">
                                24.1236 BTC
                            </div>
                            <div className="fs-13 fw-400 text-lightblue">
                                3,700.96 INR
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-group formInputs">                
                    <input className="form-control" type="text" name="" placeholder="Enter your Destination Address" />
                </div> 
                <div className="form-group formInputs">                
                        <input className="form-control" type="text" name="" placeholder="Enter Your Amount Withdraw" />
                 </div> 
                 <div className="text-right mb-3">
                     <span className="text-primary fs-14 fw-400">
                            $1,000,000.00 daily withdrawal limit.
                     </span>
                 </div>
                 <div className="form-group formInputs">                
                        <input className="form-control" type="text" name="" placeholder="Withdraw Fee" />
                  </div> 
                  <div className="form-group formInputs">                
                        <input className="form-control" type="text" name="" placeholder="Final Amount" />
                  </div> 
                  <div className="form-group formInputs">                
                        <input className="form-control" type="text" name="" placeholder="Remarks" />
                   </div> 
                   
                   <button className="btn btn-primary fs-14 fw-400" type="button">Withdraw</button>

    </div>
</div>
        </>
     );
}
 
export default TotalWalletAmt;