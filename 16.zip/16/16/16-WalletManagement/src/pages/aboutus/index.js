import React from 'react';

import './aboutus.scss';

import aboutus from '../../assets/images/aboutus.png';
import about_img1 from '../../assets/images/about_img1.png';
import about_img2 from '../../assets/images/about_img2.png';

import about_user1 from '../../assets/images/about_user1.png';
import about_user2 from '../../assets/images/about_user2.png';
import about_user3 from '../../assets/images/about_user3.png';
import about_user4 from '../../assets/images/about_user4.png';


const AboutUsPage = () => {
    return (
        <div className="maincontent homepage">

            <div className="aboutusBanner">
                <div className="container position-relative">
                    <div className="row bannerTit">
                        <div className="col-lg-6">
                            <div className="fs-36 fw-600 text-white mb-4">About Us</div>
                            <div className="fs-16 fw-400 text-white">Beyond operating the world's leading cryptocurrency exchange, spans an entire ecosystem.</div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <img src={aboutus} className="img-fluid" />
                        </div>
                    </div>
                </div>
            </div>

            <div className="pageContent">
                <div className="container mb-5">
                    <div className="row justify-content-center mb-5">
                        <div className="col-lg-7 col-md-8">
                            <div className="fs-36 fw-600 text-color mb-4">Exchange powers the crypto economy</div>
                            <div className="cms_para mb-md-0 mb-5">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged
                            </div>
                        </div>
                        <div className="col-lg-5 col-md-4">
                            <div>
                                <img src={about_img1} className="img-fluid" />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="fs-36 fw-600 text-color mb-5 text-center">Our executive team</div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="mb-4 text-center">
                                <div className="mb-3">
                                    <img src={about_user1} className="img-aboutUser" />
                                </div>
                                <div className="fs-16 fw-700 mb-3">Brian Armstrong</div>
                                <div className="fs-16 fw-400 text-gray">Co-Founder & Chief Executive&nbsp;Officer</div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="mb-4 text-center">
                                <div className="mb-3">
                                    <img src={about_user2} className="img-aboutUser" />
                                </div>
                                <div className="fs-16 fw-700 mb-3">Emilie Choi</div>
                                <div className="fs-16 fw-400 text-gray">President & Chief Operating&nbsp;Officer</div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <div className="mb-4 text-center">
                                <div className="mb-3">
                                    <img src={about_user3} className="img-aboutUser" />
                                </div>
                                <div className="fs-16 fw-700 mb-3">Surojit Chatterjee</div>
                                <div className="fs-16 fw-400 text-gray">Chief Product&nbsp;Officer</div>
                            </div>
                        </div>

                        <div className="col-lg-3 col-md-6">
                            <div className="mb-4 text-center">
                                <div className="mb-3">
                                    <img src={about_user4} className="img-aboutUser" />
                                </div>
                                <div className="fs-16 fw-700 mb-3">Alesia Haas</div>
                                <div className="fs-16 fw-400 text-gray">Chief Product&nbsp;Officer</div>
                            </div>
                        </div>

                    </div>
                    <div className="row justify-content-center mt-5">
                        <div className="col-lg-7 col-md-8">
                            <div className="fs-36 fw-600 text-color mb-4">Working at Exchange</div>
                            <div className="cms_para mb-md-0 mb-5">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged
                            </div>
                        </div>
                        <div className="col-lg-5 col-md-4">
                            <div>
                                <img src={about_img2} className="img-fluid" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AboutUsPage;