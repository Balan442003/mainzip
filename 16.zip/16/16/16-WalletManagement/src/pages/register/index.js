// import React from 'react';
// import { Link } from 'react-router-dom';
// import { useForm } from "react-hook-form";
// import { yupResolver } from "@hookform/resolvers/yup";
// import * as yup from "yup";
// import user from '../../assets/images/user.png'
// import lock from '../../assets/images/lock.png'
// import login_bg from '../../assets/images/login_bg.png'
// import message from '../../assets/images/message.png'


// const schema = yup.object({
//     Name: yup.string()
//         .required("Name is required")
//         .min(3, "Name must be atleast 3 Characters")
//         .max(30, "Name is too length")
//         .trim(),
//     email: yup.string()
//         .required("Email is required")
//         .email("Email is invalid")
//         .lowercase()
//         .matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g, 'Must Be in Email Format')
//         .trim(),
//     password: yup
//         .string()
//         .min(6, "Password must be at least 6 characters")
//         .matches(/(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$/g, 'Password should need atleast 1 uppercase & 1 lowercase & 1 special character & 1 lowercase')
//         .required("Password is required").trim(),
//     confirmPassword: yup
//         .string()
//         .oneOf([yup.ref("password")], "Passwords must match")
//         .required("Confirm Password is required")
//         .trim(),
//     acceptTerms: yup.bool()
//         .oneOf([true], 'Accept Terms & Conditions is required'),
// });
// const Registerpage = () => {
//     const {
//         register,
//         handleSubmit,
//         formState: { errors },
//     } = useForm({
//         resolver: yupResolver(schema),
//         mode: "all",
//     });
//     const onSubmit = async (data) => {
//         try {
//             console.log(data);
//         } catch (err) {
//             console.log(err);
//         }
//     }
//     return (
//         <div className="maincontent">
//             <div className="pageContent">
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12">
//                             <div className="card mycard">
//                                 <div className="card-body p-md-5 p-3">
//                                     <div className="row justify-content-center">
//                                         <div className="col-lg-6 col-md-8 col-sm-10">
//                                             <form onSubmit={handleSubmit(onSubmit)}>
//                                                 <div className="text-center fs-36 fw-700 mb-4">Register</div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={user} />
//                                                             </span>
//                                                         </div>
//                                                         <input {...register("Name")} autoFocus className={`form-control ${errors.Name ? "is-invalid" : ""}`} type="text" name="Name" placeholder="Enter Your Name" />
//                                                         <div className="invalid-feedback">{errors.Name?.message}</div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={message} />
//                                                             </span>
//                                                         </div>
//                                                         <input {...register("email")} className={`form-control ${errors.email ? "is-invalid" : ""}`} type="text" name="email" placeholder="Enter Your Email Id" />
//                                                         <div className="invalid-feedback">{errors.email?.message}</div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={lock} />
//                                                             </span>
//                                                         </div>
//                                                         <input {...register("password")} className={`form-control ${errors.password ? "is-invalid" : ""}`} type="password" name="password" placeholder="Enter Your Password" />
//                                                         <div className="invalid-feedback">{errors.password?.message}</div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={lock} />
//                                                             </span>
//                                                         </div>
//                                                         <input {...register("confirmPassword")} className={`form-control ${errors.confirmPassword ? "is-invalid" : ""}`} type="password" name="confirmPassword" placeholder="Enter Your Confirm Password" />
//                                                         <div className="invalid-feedback">{errors.confirmPassword?.message}</div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="mb-5">
//                                                     <div className="custom-control custom-checkbox custom-control-inline custom_checkbox">
//                                                         <input {...register("acceptTerms")} type="checkbox" className={`form-check-input ${errors.acceptTerms ? 'is-invalid' : ''}`} id="customCheck" name="acceptTerms" />
//                                                         <label className="custom-control-label fs-12 fw-300 pt-1 lh-15 text-black" for="customCheck">I agree to our
//                                                             <Link to='/terms' className="d-inline-block text-primary"> Terms and Conditions</Link>
//                                                             &nbsp;and&nbsp;
//                                                             <Link to='/' className="d-inline-block text-primary">Data Protection Guidelines.</Link>
//                                                         </label>
//                                                         <div className="invalid-feedback">{errors.acceptTerms?.message}</div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="text-center mb-4">
//                                                     <button className="btn btn-primary fs-16 fw-400" type="button">Register</button>
//                                                 </div>
//                                             </form>
//                                             <div className="text-gray2 text-center fs-15 fw-600">Already have an account <Link to="/login" className="d-inline-block fw-700 text-primary">Login</Link></div>
//                                         </div>
//                                         <div className="col-lg-6 text-center d-none d-lg-block">
//                                             <img alt="" src={login_bg} className="img-fluid" />
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default Registerpage;

// import React, { useState } from "react";
// import { useNavigate } from 'react-router-dom';
// import { Link } from "react-router-dom";
// import { ToastContainer, toast } from 'react-toastify';
// import { useForm, Controller } from "react-hook-form";
// import { yupResolver } from "@hookform/resolvers/yup";
// import * as Yup from "yup";
// import { useAddUserMutation } from '../../component/redux/registerapi'
// import user from "../../assets/images/user.png";
// import lock from "../../assets/images/lock.png";
// import login_bg from "../../assets/images/login_bg.png";
// import message from "../../assets/images/message.png";

// const validationSchema = Yup.object().shape({
//     name: Yup.string().required("Name is required")
//         .min(3, "Name must be atleast 3 Characters")
//         .max(30, "Name is too length")
//         .trim(),
//     email: Yup.string().email("Invalid email").required("Email is required")
//         .lowercase()
//         .matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g, 'Must Be in Email Format')
//         .trim(),
//     password: Yup.string().required("Password is required")
//         .min(6, "Password must be at least 6 characters")
//         .matches(/(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$/g, 'Password should need atleast 1 uppercase & 1 lowercase & 1 special character & 1 lowercase')
//         .trim(),
//     confirmPassword: Yup.string()
//         .oneOf([Yup.ref("password"), null], "Passwords must match")
//         .required("Confirm Password is required"),
//     agreeTerms: Yup.bool()
//         .oneOf([true], "Accept Terms & Conditions is required"),
// });

// const Registerpage = () => {
//     const [selectedFile, setSelectedFile] = useState(null);

//     const navigate = useNavigate();
//     const {
//         handleSubmit,
//         control,
//         register,
//         reset,
//         formState: { errors },
//     } = useForm({
//         resolver: yupResolver(validationSchema),
//         mode: "all",
//     });

//     // function Verify() {

//     //     // if(loginuser){
//     //     try {
//     //         if (otp !== '1111') {
//     //             toast.error("Invalid OTP")
//     //         }
//     //         else {
//     //             toast.success("Successfully login")
//     //             setTimeout(() => {
//     //                 navigate("/Dashboard")
//     //             }, 3000)
//     //         }
//     //     } catch (error) {
//     //         alert("Something went wrong")
//     //     }
//     const handleImageUpload = (e) => {
//         const file = e.target.files[0];
//         setSelectedFile(file);
//     };


//     const onSubmit = (data) => {
//         // Handle the form submission logic here
//         console.log(data);
//         localStorage.setItem('walletusers', JSON.stringify(data))
//         toast.success("Register Successfully")
//         reset()
//         setTimeout(() => {
//             navigate('/Registerotp')
//         }, 3000);
//     };


//     return (
//         <div className="maincontent">
//             <div className='toast-container'>
//                 <ToastContainer limit={2} />
//             </div>
//             <div className="pageContent">
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-12">
//                             <div className="card mycard">
//                                 <div className="card-body p-md-5 p-3">
//                                     <div className="row justify-content-center">
//                                         <div className="col-lg-6 col-md-8 col-sm-10">
//                                             <form onSubmit={handleSubmit(onSubmit)}>
//                                                 <div className="text-center fs-36 fw-700 mb-4">
//                                                     Register
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={user} />
//                                                             </span>
//                                                         </div>
//                                                         <Controller
//                                                             name="name"
//                                                             control={control}
//                                                             render={({ field }) => (
//                                                                 <input
//                                                                     {...field}
//                                                                     className="form-control py-0"
//                                                                     type="text"
//                                                                     placeholder="Enter Your Name"
//                                                                 />
//                                                             )}
//                                                         />
//                                                     </div>
//                                                     {errors?.name && (
//                                                         <p className="error-message text-danger">
//                                                             {errors.name.message}
//                                                         </p>
//                                                     )}
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={message} />
//                                                                 profileImage
//                                                             </span>

//                                                         </div>

//                                                         {/* <input
//                                                             type="file"
//                                                             accept=".gif, .png, .jpeg, .jpg"
//                                                             onChange={(e) => handleImageUpload(e)}
//                                                             {...register("profileImage")}
//                                                             className={`form-control ${errors.profileImage ? "is-invalid" : ""}`}
//                                                         /> */}
//                                                         <Controller
//                                                             name="profileImage"
//                                                             control={control}
//                                                             render={({ field }) => (
//                                                                 <input
//                                                                     {...field}
//                                                                     className="form-control py-0"
//                                                                     type="file"
//                                                                 />
//                                                             )}
//                                                         />
//                                                         {selectedFile && (
//                                                             <p>
//                                                                 Selected file: {selectedFile.name} ({selectedFile.type})
//                                                             </p>
//                                                         )}
//                                                     </div>
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={message} />
//                                                             </span>
//                                                         </div>
//                                                         <Controller
//                                                             name="email"
//                                                             control={control}
//                                                             render={({ field }) => (
//                                                                 <input
//                                                                     {...field}
//                                                                     className="form-control py-0"
//                                                                     type="text"
//                                                                     placeholder="Enter Your Email Id"
//                                                                 />
//                                                             )}
//                                                         />
//                                                     </div>
//                                                     {errors?.email && (
//                                                         <p className="error-message  text-danger">
//                                                             {errors.email.message}
//                                                         </p>
//                                                     )}
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={lock} />
//                                                             </span>
//                                                         </div>
//                                                         <Controller
//                                                             name="password"
//                                                             control={control}
//                                                             render={({ field }) => (
//                                                                 <input
//                                                                     {...field}
//                                                                     className="form-control py-0"
//                                                                     type="password"
//                                                                     placeholder="Enter Your Password"
//                                                                 />
//                                                             )}
//                                                         />
//                                                     </div>
//                                                     {errors?.password && (
//                                                         <p className="error-message  text-danger">
//                                                             {errors.password.message}
//                                                         </p>
//                                                     )}
//                                                 </div>
//                                                 <div className="form-group formInputs mb-4">
//                                                     <div className="input-group iconinput">
//                                                         <div className="input-group-prepend">
//                                                             <span className="input-group-text">
//                                                                 <img alt="" src={lock} />
//                                                             </span>
//                                                         </div>
//                                                         <Controller
//                                                             name="confirmPassword"
//                                                             control={control}
//                                                             render={({ field }) => (
//                                                                 <input
//                                                                     {...field}
//                                                                     className="form-control py-0"
//                                                                     type="password"
//                                                                     placeholder="Enter Your Confirm Password"
//                                                                 />
//                                                             )}
//                                                         />
//                                                     </div>
//                                                     {errors?.confirmPassword && (
//                                                         <p className="error-message text-danger">
//                                                             {errors.confirmPassword.message}
//                                                         </p>
//                                                     )}
//                                                 </div>
//                                                 <div className="mb-5">
//                                                     <div className="custom-control custom-checkbox custom-control-inline custom_checkbox">
//                                                         <Controller
//                                                             name="agreeTerms"
//                                                             control={control}
//                                                             render={({ field }) => (
//                                                                 <input
//                                                                     type="checkbox"
//                                                                     className="custom-control-input"
//                                                                     id="customCheck"
//                                                                     {...field}
//                                                                 />
//                                                             )}
//                                                         />
//                                                         <label
//                                                             className="custom-control-label fs-12 fw-300 pt-1 lh-15 text-black"
//                                                             htmlFor="customCheck"
//                                                         >
//                                                             I agree to our
//                                                             <Link
//                                                                 to="/terms"
//                                                                 className="d-inline-block text-primary"
//                                                             >
//                                                                 {" "}
//                                                                 Terms and Conditions
//                                                             </Link>
//                                                             &nbsp;and&nbsp;
//                                                             <Link
//                                                                 to="/"
//                                                                 className="d-inline-block text-primary"
//                                                             >
//                                                                 Data Protection Guidelines.
//                                                             </Link>
//                                                         </label>
//                                                     </div>
//                                                     {errors?.agreeTerms && (
//                                                         <p className="error-message text-danger">
//                                                             {errors.agreeTerms.message}
//                                                         </p>
//                                                     )}
//                                                 </div>
//                                                 <div className="text-center mb-4">
//                                                     <button
//                                                         className="btn btn-primary fs-16 fw-400"
//                                                         type="submit"
//                                                     >
//                                                         Register
//                                                     </button>
//                                                 </div>
//                                             </form>
//                                             <div className="text-gray2 text-center fs-15 fw-600">
//                                                 Already have an account{" "}
//                                                 <Link
//                                                     to="/login"
//                                                     className="d-inline-block fw-700 text-primary"
//                                                 >
//                                                     Login
//                                                 </Link>
//                                             </div>
//                                         </div>
//                                         <div className="col-lg-6 text-center d-none d-lg-block">
//                                             <img alt="" src={login_bg} className="img-fluid" />
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>

//         </div>
//     );
// }

// export default Registerpage;


import React from 'react';
import { Link } from 'react-router-dom';
import user from '../../assets/images/user.png'
import lock from '../../assets/images/lock.png'
import login_bg from '../../assets/images/login_bg.png'
import message from '../../assets/images/message.png'
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { useCreateUserMutation } from '../../component/redux/registerapi';
import { ToastContainer, toast } from 'react-toastify';


const schema = Yup.object().shape({
    userName: Yup.string().required('Name is required')
        .matches(/^[A-Za-z]+$/, 'Characters Only allowed')
        .min(3, 'Username must be atleast 3 characters')
        .max(20, 'Username must be less than 20 characters')
        .trim(),
    email: Yup.string().required('Email is required')
        .email('Email is invalid')
        .matches(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/, 'Enter valid email')
        .trim()
    ,
    password: Yup.string()
        .required('Password is required')
        .matches(/[A-Z]/, 'Please Give One or More UpperCase Letters')
        .matches(/[0-9]/, 'Please One or More Numbers')
        .matches(/[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/, 'Please Give One or More Special Characters')
        .min(8, 'Password must be at least 8 characters')
        .trim(),
    confirmPassword: Yup.string()
        .oneOf([Yup.ref('password'), null], 'Passwords does not match')
        .required('Confirm Password is required')
        .trim(),
    acceptTerms: Yup.bool().oneOf([true], 'Accept Terms & Conditions is required'),
});

const Registerpage = () => {
    const navigate = useNavigate()
    const [createUser] = useCreateUserMutation()
    const { register, handleSubmit, formState: { errors }, reset } = useForm({
        resolver: yupResolver(schema),
        mode: 'all'

    });

    const CreateUser = async (data) => {
        try {
            const response = await createUser(data)
            if (response.error) {
                const otperrorMessage = response.error.data.message
                toast.error(otperrorMessage, {
                    position: toast.POSITION.TOP_CENTER
                })
            } else {
                const otpMsg = response.data.data.otp.code
                console.log(otpMsg);
                const getUserID = response.data.data._id
                localStorage.setItem('userId', getUserID)
                toast.info(`Your OTP ${otpMsg}`, {
                    position: toast.POSITION.TOP_CENTER,
                    autoClose: 10000,
                    closeOnClick: true
                });
                navigate('/registerotp')

            }
        } catch (err) {
            console.log(err.message)
            toast.error('SomeThing Went Wrong', {
                position: toast.POSITION.TOP_CENTER
            })
        }

    }

    return (

        <div className="maincontent">
            <div className='toast-container'>
                <ToastContainer limit={2} />
            </div>
            <div className="pageContent">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="card mycard">
                                <div className="card-body p-md-5 p-3">
                                    <div className="row justify-content-center">
                                        <div className="col-lg-6 col-md-8 col-sm-10">
                                            <div className="text-center fs-36 fw-700 mb-4">Register</div>
                                            <form onSubmit={handleSubmit(CreateUser)}>
                                                <div className="form-group formInputs mb-4">
                                                    <div className="input-group iconinput">
                                                        <div className="input-group-prepend">
                                                            <span className="input-group-text">
                                                                <img alt="" src={user} />
                                                            </span>
                                                        </div>
                                                        <input
                                                            className={`form-control  ${errors?.userName ? 'is-invalid' : ''
                                                                }`}
                                                            type="text"
                                                            name="userName"
                                                            {...register('userName')}
                                                            placeholder="Enter Your Name" />
                                                        <div className="invalid-feedback ">
                                                            <span style={{ margin: "13px" }}>{errors?.userName?.message}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-group formInputs mb-4">
                                                    <div className="input-group iconinput">
                                                        <div className="input-group-prepend">
                                                            <span className="input-group-text">
                                                                <img alt="" src={message} />
                                                            </span>
                                                        </div>
                                                        <input
                                                            className={`form-control  ${errors?.email ? 'is-invalid' : ''}`}
                                                            type="text"
                                                            name="email"
                                                            {...register('email')}
                                                            placeholder="Enter Your Email Id" />
                                                        <div className="invalid-feedback ">
                                                            <span style={{ margin: "13px" }}>{errors?.email?.message}</span>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div className="form-group formInputs mb-4">
                                                    <div className="input-group iconinput">
                                                        <div className="input-group-prepend">
                                                            <span className="input-group-text">
                                                                <img alt="" src={lock} />
                                                            </span>
                                                        </div>
                                                        <input
                                                            className={`form-control  ${errors?.password ? 'is-invalid' : ''}`}
                                                            type="password"
                                                            name="password"
                                                            {...register('password')}
                                                            placeholder="Enter Your Password" />
                                                        <div className="invalid-feedback ">
                                                            <span style={{ margin: "13px" }}>{errors?.password?.message}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-group formInputs mb-4">
                                                    <div className="input-group iconinput">
                                                        <div className="input-group-prepend">
                                                            <span className="input-group-text">
                                                                <img alt="" src={lock} />
                                                            </span>
                                                        </div>
                                                        <input
                                                            className={`form-control  ${errors?.password ? 'is-invalid' : ''}`} type="password"
                                                            {...register('confirmPassword')}
                                                            name="confirmPassword"
                                                            placeholder="Enter Your Confirm Password" />
                                                        <div className="invalid-feedback ">
                                                            <span style={{ margin: "13px" }}>{errors?.confirmPassword?.message}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="mb-5">
                                                    <div className="custom-control custom-checkbox custom-control-inline custom_checkbox">
                                                        <input
                                                            type="checkbox"
                                                            className={`custom-control-input  ${errors?.acceptTerms ? 'is-invalid' : ''}`}
                                                            id="customCheck"
                                                            {...register('acceptTerms')}
                                                            name="acceptTerms" />
                                                        <label className="custom-control-label fs-12 fw-300 pt-1 lh-15 text-black" for="customCheck">I agree to our
                                                            <Link to='/terms' className="d-inline-block text-primary"> Terms and Conditions</Link>
                                                            &nbsp;and&nbsp;
                                                            <Link to='/' className="d-inline-block text-primary">Data Protection Guidelines.</Link>
                                                        </label>

                                                        <div className="invalid-feedback ">
                                                            <span style={{ margin: "13px" }}>{errors?.acceptTerms?.message}</span>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div className="text-center mb-4">
                                                    <button className="btn btn-primary fs-16 fw-400" >Register</button>
                                                </div>
                                            </form>
                                            <div className="text-gray2 text-center fs-15 fw-600">Already have an account <Link to="/login" className="d-inline-block fw-700 text-primary">Login</Link></div>
                                        </div>
                                        <div className="col-lg-6 text-center d-none d-lg-block">
                                            <img alt="" src={login_bg} className="img-fluid" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Registerpage;
