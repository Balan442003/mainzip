import React from 'react';
import './bankdetails.scss';
import idcard from '../../assets/images/idcard.png';
import calendar from '../../assets/images/calendar.png';
import bank from '../../assets/images/bank.png';
import bank1 from '../../assets/images/bank1.png';
import bank2 from '../../assets/images/bank2.png';
import globallocate from '../../assets/images/global-locate.png';
import user from '../../assets/images/user.png';
import location from '../../assets/images/location.png';
import edit_blue from '../../assets/images/edit_blue.png';
import delete_blue from '../../assets/images/delete_blue.png';
import DropFileInput from '../../component/drop-file-input/DropFileInput';

const BankDetailspage = () => {
    const onFileChange = (files) => {
        console.log(files);
    }
    return (
        <div class="py-4 pageContent">
            <div class="container-fluid">

                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div>
                            <ul class="steps">
                                <li class="steplevel"><span>ID Proof 1</span></li>
                                <li class="steplevel processing"><span>ID Proof 2</span></li>
                                <li class="steplevel "><span>Bank Details</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center mt-4">
                    <div class="col-lg-9">
                        <div class="IDproof_sec">
                            <div class="fs-20 fw-600 mb-3">KYC Verfications</div>
                            <div class="row">
                                <div class="col-lg-4">

                                    <div class="form-inline mb-5">
                                        <label class="mr-3 text-gray fs-16 fw-400">Select Country</label>
                                        <select class="custom-select" style={{ minWidth: "230px", height: "50px" }}>
                                            <option>India</option>
                                        </select>
                                    </div>
                                    <div class="fs-18 fw-600 mb-4">Aadhar card</div>
                                    <div class="form-group formInputs mb-4">
                                        <div class="input-group iconinput">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <img src={idcard} />
                                                </span>
                                            </div>
                                            <input class="form-control py-0" type="text" name="" placeholder="Enter your Name as per your aadhar card" />
                                        </div>
                                    </div>
                                    <div class="form-group formInputs mb-4">
                                        <div class="input-group iconinput">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <img src={idcard} />
                                                </span>
                                            </div>
                                            <input class="form-control py-0" type="text" name="" placeholder="Enter your aadhar card Number" />
                                        </div>
                                    </div>
                                    <div class="form-group formInputs mb-4">
                                        <div class="input-group iconinput">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <img src={calendar} />
                                                </span>
                                            </div>
                                            <input class="form-control py-0" type="text" name="" placeholder="Date of Birth" />
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-8">
                                    <div class="fs-16 fw-600 mb-2">Upload Aadhar Card</div>
                                    <div class="fs-14 fw-400 text-gray mb-4">* Format: JPEG (.jpg or .jpeg) or PNG format, Size: less than 5MB</div>
                                    <div class="card mycard border-radius-20">
                                        <div class="card-body px-5 pt-4 pb-0">
                                            <div className='row'>
                                                <div className='col-md-6'>
                                                    <DropFileInput onFileChange={(files) => onFileChange(files)} />
                                                </div>
                                                <div className='col-md-6'>
                                                    <DropFileInput onFileChange={(files) => onFileChange(files)} />
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center fs-14 fw-400 text-gray mb-4">
                                <span class="text-primary">Note</span>
                                To change the country later, you can raise a ticket to and ask us to reset your KYC.
                            </div>
                            <div class="text-center">
                                <button class="btn btn-primary" type="button">Submit</button>
                            </div>
                        </div>

                        <div class="bank-details_sec">
                            <div class="fs-20 fw-600 mb-3">Bank Details</div>

                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="card mycard border-radius-20 mb-4">
                                        <div class="card-body">
                                            <div class="d-flex">
                                                <div class="">
                                                    <img src={bank1} class="img-w57 mr-3" />
                                                </div>
                                                <div>
                                                    <div class="fs-18 fw-700 mb-2">Peter park</div>
                                                    <div class="fs-14 fw-400">1000004350435435</div>
                                                    <div class="fs-14 fw-400">IFSC code  KVB0002342</div>

                                                    <div class="text-green my-2">Verfied</div>
                                                    <button class="btn bg-transparent fs-14 fw-400" type="button"><img src={edit_blue} /> Edit</button>
                                                    <button class="btn bg-transparent fs-14 fw-400" type="button"><img src={delete_blue} /> Delete</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="card mycard border-radius-20 mb-4">
                                        <div class="card-body">
                                            <div class="d-flex">
                                                <div class="">
                                                    <img src={bank2} class="img-w57 mr-3" />
                                                </div>
                                                <div>
                                                    <div class="fs-18 fw-700 mb-2">Peter park</div>
                                                    <div class="fs-14 fw-400">1000004350435435</div>
                                                    <div class="fs-14 fw-400">IFSC code  KVB0002342</div>

                                                    <div class="text-warning my-2">Pending</div>
                                                    <button class="btn bg-transparent fs-14 fw-400" type="button"><img src={edit_blue} /> Edit</button>
                                                    <button class="btn bg-transparent fs-14 fw-400" type="button"><img src={delete_blue} /> Delete</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="fs-20 fw-600 mb-3">Add Bank Details</div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card mycard">
                                        <div class="card-body">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-9">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group formInputs mb-4">
                                                                <div class="input-group iconinput">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <img src={globallocate} />
                                                                        </span>
                                                                    </div>
                                                                    <select class="form-control py-0" type="text" name="" placeholder="Select Your Country">
                                                                        <option>country 1</option>
                                                                        <option>country 2</option>
                                                                        <option>country 3</option>
                                                                        <option>country 4</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group formInputs mb-4">
                                                                <div class="input-group iconinput">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <img src={bank} />
                                                                        </span>
                                                                    </div>
                                                                    <select class="form-control py-0" type="text" name="" placeholder="Select You Bank">
                                                                        <option>bank 1</option>
                                                                        <option>bank 2</option>
                                                                        <option>bank 3</option>
                                                                        <option>bank 4</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group formInputs mb-4">
                                                                <div class="input-group iconinput">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <img src={user} />
                                                                        </span>
                                                                    </div>
                                                                    <input class="form-control py-0" type="text" name="" placeholder="User Account Name" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group formInputs mb-4">
                                                                <div class="input-group iconinput">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <img src={user} />
                                                                        </span>
                                                                    </div>
                                                                    <input class="form-control py-0" type="text" name="" placeholder="User Account Number" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group formInputs mb-4">
                                                                <div class="input-group iconinput">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <img src={location} />
                                                                        </span>
                                                                    </div>
                                                                    <input class="form-control py-0" type="text" name="" placeholder="NEFT Code / IFSC Code" />
                                                                </div>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center mt-3">
                                                <button class="btn btn-primary" type="text">Add Bank</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>

    );
}

export default BankDetailspage;

