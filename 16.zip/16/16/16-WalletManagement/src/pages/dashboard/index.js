import React, { useState } from 'react';

import userImg from '../../assets/images/userImg.png';
import walletsm from '../../assets/images/wallet_sm.png';
import dollarsign from '../../assets/images/dollar-sign.png';
import Google_Chrome_icon from '../../assets/images/Google_Chrome_icon.png';
import Android_robot from '../../assets/images/Android_robot.png';
import icon1 from '../../assets/images/icon1.png';
import withdraw_sm from '../../assets/images/withdraw_sm.png';
import icon2 from '../../assets/images/icon2.png';
import icon3 from '../../assets/images/icon3.png';
import icon4 from '../../assets/images/icon4.png';
import icon5 from '../../assets/images/icon5.png';
import icon6 from '../../assets/images/icon6.png';
import icon7 from '../../assets/images/icon7.png';
import icon8 from '../../assets/images/icon8.png';
import icon9 from '../../assets/images/icon9.png';
import icon10 from '../../assets/images/icon10.png';
import icon11 from '../../assets/images/icon11.png';
import btc_64 from '../../assets/images/btc_64.png';
import qr_code from '../../assets/images/qr_code.png';
import copyIcon from '../../assets/images/copyIcon.png';

const Dashboard = () => {
    const [isActive, setIsActive] = useState(false);
    const [isType, setIsType] = useState("deposit");
    const [isDeposit, setIsDeposit] = useState(false);
    const [isWithdraw, setIsWithdraw] = useState(false)


    // const rightsideOpenDeposit = () =>{
    //     setIsActive(current => !current);
    //     setIsDeposit(true);
    //     setIsWithdraw(false);
    // }

    // const rightsideOpenWithdraw = () => {
    //     setIsActive(current => !current);
    //     setIsDeposit(false);
    //     setIsWithdraw(true);
    // }

    //    const rightsideOpen = () => {
    //     setIsActive(current => !current);
    //    }
    const rightsideOpen = type => {
        setIsActive(current => !current);
        if (isType !== type) setIsType(type)

    }

    const closeRSide = () => {
        setIsActive(current => !current);
    }


    return (
        <>
            <div className="py-4 pageContent">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="fs-20 fw-700 mb-3">Profile Details</div>
                            <div className="bordercard p-4 mb-4">
                                <div className="row">
                                    <div className="col-md-4">
                                        <div className="user_img mb-4 text-center">
                                            <img alt="" src={userImg} className="img-fluid" />
                                        </div>
                                        <div className="text-center">
                                            <button className="btn btn-primary" type="button">Edit</button>
                                        </div>
                                    </div>
                                    <div className="col-md-8">
                                        <div className="d-flex mb-5">
                                            <div className="mr-3 mt-2">
                                                <div className="icon_wizard">
                                                    <div className="iconbox">
                                                        <img alt="" src={walletsm} />
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div className="text-lightblue fs-14 fw-400">Your Balance </div>
                                                <div className="text-color fs-22 fw-400">0.000147843 INR</div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-sm-6 mb-4">
                                                <div className="text-lightblue fs-14 fw-400">User ID</div>
                                                <div className="text-color fs-18 fw-400">5789278944</div>
                                            </div>
                                            <div className="col-sm-6 mb-4">
                                                <div className="text-lightblue fs-14 fw-400">Name</div>
                                                <div className="text-color fs-18 fw-400">John doe</div>
                                            </div>
                                            <div className="col-sm-6 mb-4">
                                                <div className="text-lightblue fs-14 fw-400">Email</div>
                                                <div className="text-color fs-18 fw-400">johndoe@mail.com</div>
                                            </div>
                                            <div className="col-sm-6 mb-4">
                                                <div className="text-lightblue fs-14 fw-400">Phone number</div>
                                                <div className="text-color fs-18 fw-400">+ 1 2485-448-4846</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="fs-20 fw-700 mb-3">Security Details</div>
                            <div className="bordercard p-4 mb-4">
                                <div className="row">
                                    <div className="col-md-6 mb-4 mb-md-0">
                                        <div className="d-flex">
                                            <div className="mr-3 mt-2">
                                                <div className="icon_wizard">
                                                    <div className="iconbox">
                                                        <img alt="" src={dollarsign} />
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div className="text-lightblue fs-14 fw-400 mb-2">KYC Verfication </div>
                                                <div className="">
                                                    <button className="btn btn-outline-success fs-14 fw-700 rounded-pill px-3" type="button">Verified</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="d-flex">
                                            <div className="mr-3 mt-2">
                                                <div className="icon_wizard">
                                                    <div className="iconbox">
                                                        <img alt="" src={dollarsign} />
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div className="text-lightblue fs-14 fw-400 mb-2">Two Factor authentication</div>
                                                <div className="">
                                                    <button className="btn btn-outline-danger fs-14 fw-700 rounded-pill px-3" type="button">Disable</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="fs-20 fw-700 mb-3">Login History</div>
                            <div className="bordercard p-0">
                                <div className="table-responsive">
                                    <table className="table mytable appTable table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Browser</th>
                                                <th>IP</th>
                                                <th>Last Seen</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><img alt="" src={Google_Chrome_icon} /> Chrome</td>
                                                <td>15-07-2021 </td>
                                                <td>Active Now <span className="green_sm_cir"></span></td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Android_robot.png} /> Samsung</td>
                                                <td>15-07-2021 </td>
                                                <td>3hrs ago</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Google_Chrome_icon} /> Chrome</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Android_robot.png} /> Samsung</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Google_Chrome_icon} /> Chrome</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Android_robot.png} /> Samsung</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Google_Chrome_icon} /> Chrome</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Android_robot.png} /> Samsung</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Google_Chrome_icon} /> Chrome</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                            <tr>
                                                <td><img alt="" src={Android_robot.png} /> Samsung</td>
                                                <td>15-07-2021 </td>
                                                <td>15-07-2021 21:45:21</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="fs-20 fw-700 mb-3">Your Crypto Balance</div>
                            <div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon1} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">BTC</div>
                                                            <div className="text-green fs-14 fw-400">+0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button" onClick={() => { rightsideOpen("deposit"); }}>
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button" onClick={() => { rightsideOpen("withdraw"); }}>
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon2} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">ETH</div>
                                                            <div className="text-red fs-14 fw-400">-0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon3} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">BTC</div>
                                                            <div className="text-green fs-14 fw-400">+0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon4} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">ETH</div>
                                                            <div className="text-red fs-14 fw-400">-0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon5} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">BTC</div>
                                                            <div className="text-green fs-14 fw-400">+0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon6} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">ETH</div>
                                                            <div className="text-red fs-14 fw-400">-0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon7} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">BTC</div>
                                                            <div className="text-green fs-14 fw-400">+0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon8} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">ETH</div>
                                                            <div className="text-red fs-14 fw-400">-0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon9} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">BTC</div>
                                                            <div className="text-green fs-14 fw-400">+0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon10} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">ETH</div>
                                                            <div className="text-red fs-14 fw-400">-0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="bordercard borhover mb-3">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="d-flex">
                                                        <div className="mr-3">
                                                            <img alt="" src={icon11} className="img-w40" />
                                                        </div>
                                                        <div>
                                                            <div className="fs-16 fw-700">ETH</div>
                                                            <div className="text-red fs-14 fw-400">-0.7%</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-6 text-center">
                                                    <div className="text-gray fs-13 fw-400">Your Balance</div>
                                                    <div className="fs-16 fw-500">1.526  BTC</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-6 text-center">
                                            <button className="btn btn-primary mw-auto py-2 px-4 mw-auto fs-14 fw-400" type="button">
                                                <img alt="" src={walletsm} className="imgicon mr-2" /> Deposit
                                            </button>
                                            <button className="btn btn-outline-primary mw-auto py-2 mw-auto px-4 fs-14 fw-400 ml-3" type="button">
                                                <img alt="" src={withdraw_sm} className="imgicon mr-2" /> Withdraw
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className={`overlaybg ${isActive ? 'overlay_show' : ''}`} onClick={closeRSide}></div>

            <div className={`rightSide ${isActive ? 'RS_open' : ''}`}>
                {isType === "deposit" &&
                    <div className="content-deposit">
                        <div className="d-flex justify-content-between align-items-center mb-3">
                            <div className="fs-36 fw-700">Deposit</div>
                            <div>
                                <a className="alinkIcon fs-24 text-black" href="javascript:void(0);" onClick={closeRSide}>
                                    <i className="bi bi-x"></i>
                                </a>
                            </div>
                        </div>
                        <div className="d-flex align-items-center mb-5">
                            <div>
                                <img alt="" src={btc_64} className="img-w64" />
                            </div>
                            <div className="ml-4">
                                <div className="fs-24 fw-700">BTC Balance</div>
                                <div className="fs-13 fw-400 text-lightblue">Bitcoin</div>
                            </div>
                        </div>

                        <div className="secondaryborder mb-5">
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="fs-20 fw-400 text-lightblue">
                                    Total Balance
                                </div>
                                <div>
                                    <div className="fs-20 fw-400">
                                        24.1236 BTC
                                    </div>
                                    <div className="fs-13 fw-400 text-lightblue">
                                        3,700.96 INR
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="fs-16 fw-600 mb-2">
                            Address
                        </div>
                        <div className="fs-14 fw-400 text-lightblue lh-24 mb-4">
                            Only send ETH to this address. Sending any other asset to this address may result in the loss of your deposit!
                        </div>

                        <div className="bordercard borhover py-2">
                            <div className="d-flex">
                                <div className="fs-14 fw-400">
                                    KJ65FJEOW874KUSH11KDA
                                </div>
                                <div className="ml-auto">
                                    <img alt="" src={copyIcon} className="pointer" />
                                </div>
                            </div>
                        </div>

                        <div className="row justify-content-center">
                            <div className="col-lg-6">
                                <div className="my-5 text-center">
                                    <img alt="" src={qr_code} className="img-fluid" />
                                </div>
                            </div>
                        </div>

                        <div className="fs-16 fw-400 text-lightblue">Ethereum deposits are available after 2 network confirmations.</div>
                    </div>
                }
                {isType === "withdraw" &&
                    <div className="content-withdraw">
                        <div className="d-flex justify-content-between align-items-center mb-3">
                            <div className="fs-36 fw-700">Withdraw</div>
                            <div>
                                <a className="alinkIcon fs-24 text-black" href="javascript:void(0);" onClick={closeRSide}>
                                    <i className="bi bi-x"></i>
                                </a>
                            </div>
                        </div>
                        <div className="d-flex align-items-center mb-5">
                            <div>
                                <img alt="" src={btc_64} className="img-w64" />
                            </div>
                            <div className="ml-4">
                                <div className="fs-24 fw-700">BTC Balance</div>
                                <div className="fs-13 fw-400 text-lightblue">Bitcoin</div>
                            </div>
                        </div>

                        <div className="secondaryborder mb-5">
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="fs-20 fw-400 text-lightblue">
                                    Total Balance
                                </div>
                                <div>
                                    <div className="fs-20 fw-400">
                                        24.1236 BTC
                                    </div>
                                    <div className="fs-13 fw-400 text-lightblue">
                                        3,700.96 INR
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="form-group formInputs">
                            <input className="form-control" type="text" name="" placeholder="Enter your Destination Address" />
                        </div>
                        <div className="form-group formInputs">
                            <input className="form-control" type="text" name="" placeholder="Enter Your Amount Withdraw" />
                        </div>
                        <div className="text-right mb-3">
                            <span className="text-primary fs-14 fw-400">
                                $1,000,000.00 daily withdrawal limit.
                            </span>
                        </div>
                        <div className="form-group formInputs">
                            <input className="form-control" type="text" name="" placeholder="Withdraw Fee" />
                        </div>
                        <div className="form-group formInputs">
                            <input className="form-control" type="text" name="" placeholder="Final Amount" />
                        </div>
                        <div className="form-group formInputs">
                            <input className="form-control" type="text" name="" placeholder="Remarks" />
                        </div>

                        <button className="btn btn-primary fs-14 fw-400" type="button">Withdraw</button>

                    </div>
                }
            </div>
        </>
    );
}

export default Dashboard;