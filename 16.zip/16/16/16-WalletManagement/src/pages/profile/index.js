import React from 'react';

import userImg from '../../assets/images/userImg.png';
import camera from '../../assets/images/camera.png';
import user from '../../assets/images/user.png';
import message from '../../assets/images/message.png';
import phone from '../../assets/images/phone.png';
import calendar from '../../assets/images/calendar.png';
import location from '../../assets/images/location.png';
import globallocate from '../../assets/images/global-locate.png';
import lock from '../../assets/images/lock.png';


const Profilepage = () => {
    return (
        <div className="py-4 pageContent">
            <div className="container-fluid">
                <div className="row justify-content-center">
                    <div className="col-lg-10">
                        <div className="row">
                            <div className="col-lg-3">
                                <div className="text-center mt-4">
                                    <div className="pro_img">
                                        <img alt="" src={userImg} className="img-fluid" />
                                        <input type="file" id="Profileimg" className="hiddenInputfile" />
                                        <label className="uploadprofile" for="Profileimg">
                                            <img alt="" src={camera} />
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-9">
                                <div className="fs-20 fw-700 mb-3">Profile Details</div>
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={user} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your Name" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={message} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your E-mail" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={phone} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your Phone Number" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={calendar} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Date of Birth" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={location} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your State" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={location} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your City" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={location} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your Zip Code" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={globallocate} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your Country" />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div className="row mb-4">
                                    <div className="col-md-12">
                                        <button className="btn btn-primary" type="button">Submit</button>
                                        <button className="btn btn-outline-primary fs-16 fw-600 ml-3" type="button">Reset</button>
                                    </div>
                                </div>
                                <div className="fs-20 fw-700 mb-3">Change Password</div>
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={lock} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your Old Password" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={lock} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your New Password" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-group formInputs mb-4">
                                            <div className="input-group iconinput">
                                                <div className="input-group-prepend">
                                                    <span className="input-group-text">
                                                        <img alt="" src={lock} />
                                                    </span>
                                                </div>
                                                <input className="form-control py-0" type="text" name="" placeholder="Enter Your Confirm Password" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row mb-4">
                                    <div className="col-md-12">
                                        <button className="btn btn-primary" type="button">Submit</button>
                                    </div>
                                </div>
                                <div className="fs-20 fw-700 mb-3">Notification Settings</div>
                                <div className="row">
                                    <div className="col-12">
                                        <div className="d-flex mb-2">
                                            <div className="mr-auto">
                                                <label className="fs-16 fw-400" for="Emailswitch">Email Notification</label>
                                            </div>
                                            <div className="custom-control custom-switch">
                                                <input type="checkbox" className="custom-control-input" id="Emailswitch" />
                                                <label className="custom-control-label" for="Emailswitch"></label>
                                            </div>
                                        </div>
                                        <div className="d-flex mb-2">
                                            <div className="mr-auto">
                                                <label className="fs-16 fw-400" for="SMSswitch">SMS Notification</label>
                                            </div>
                                            <div className="custom-control custom-switch">
                                                <input type="checkbox" className="custom-control-input" id="SMSswitch" />
                                                <label className="custom-control-label" for="SMSswitch"></label>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default Profilepage;