// import React, { useState } from 'react';
// import OtpInput from 'react-otp-input';
// import { useNavigate } from 'react-router-dom';
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';

// export default function Otp() {
//     const [newUser] = useAddUserMutation();
//     const registeruser = JSON.parse(localStorage.getItem('walletusers'))
//     const [otp, setOtp] = useState('');
//     console.log(otp);
//     const 
//     const navigate = useNavigate();
//     const Verify = async  =>  {

//         // if(loginuser){
//         try {
//             if (otp !== '1111') {
//                 toast.error("Invalid OTP")
//             }
//             else {
//                 toast.success("Otp is valid")
//                 await newUser()
//                 setTimeout(() => {
//                     navigate("/login")
//                 }, 3000)
//             }
//         } catch (error) {
//             alert("Something went wrong")
//         }
//         // }
//     }


//     return (

//         <div className="maincontent">
//             <div className="pageContent">
//                 <div className=''>
//                     <div className='toast-container'>
//                         <ToastContainer limit={2} />
//                     </div>
//                     <div className="col-lg-12">
//                         <div className="card mycard">
//                             <div className='card-body p-md-5 p-3'>

//                                 <label><b>Enter OTP:</b></label>
//                                 <br />

//                                 <OtpInput
//                                     value={otp}
//                                     onChange={setOtp}
//                                     numInputs={4}
//                                     renderSeparator={<span>  -  </span>}
//                                     renderInput={(props) => <input {...props} />}
//                                     inputStyle={{
//                                         border: "1px solid ",
//                                         borderRadius: "8px",
//                                         width: "54px",
//                                         height: "54px",
//                                         fontSize: "12px",
//                                         color: "#000",
//                                         fontWeight: "400",
//                                         caretColor: "blue"
//                                     }}
//                                     focusStyle={{
//                                         border: "1px solid #CFD3DB",
//                                         outline: "none"
//                                     }}

//                                 />
//                                 <br />
//                                 <button className='btn btn-primary' onClick={() => Verify()}>Verify OTP</button>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }


import React from 'react';
import locked_Img from '../../assets/images/locked_Img.png'
import message from '../../assets/images/message.png'
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { useRegisterVerifyOtpMutation } from '../../component/redux/registerapi';
import { toast } from 'react-toastify';

// schema OTP validation
const schema = Yup.object().shape({
    otp: Yup.string().required('otp is required').min(6, 'Enter Six Digits Number').max(6, 'Invalid OTP').trim(),
});

const RegisterOtpPage = () => {
    const navigate = useNavigate()
    const userId = localStorage.getItem('userId')
    const { register, handleSubmit, formState: { errors }, reset } = useForm({
        resolver: yupResolver(schema),
        mode: 'all'
    });
    const [verifyOtp] = useRegisterVerifyOtpMutation()
    const onSubmit = async (data) => {
        try {
            const verifyotpNumber = await verifyOtp({ otp: data.otp, id: userId })
            if (verifyotpNumber.error) {
                const errorMessage = verifyotpNumber.error.data.message
                toast.error(errorMessage, {
                    position: toast.POSITION.TOP_CENTER
                })
                return
            }
            toast.success(verifyotpNumber.data.message, {
                position: toast.POSITION.TOP_CENTER
            })
            localStorage.removeItem('userId')
            navigate('/login')
        } catch (err) {
            console.log(err.message);
        }
    }
    return (
        <div className="maincontent">
            <div className="pageContent">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="card mycard">
                                <div className="card-body p-md-5 p-3">
                                    <div className="row justify-content-center align-items-center">
                                        <div className="col-lg-6 col-md-8 col-sm-10">

                                            <div className="row justify-content-center">
                                                <div className="col-lg-10">
                                                    <div className="text-left fs-36 fw-600 mb-4">Enter Your OTP</div>
                                                    <form onSubmit={handleSubmit(onSubmit)}>
                                                        <div className="form-group formInputs mb-5">
                                                            <div className="input-group iconinput">
                                                                <div className="input-group-prepend">
                                                                    <span className="input-group-text">
                                                                        <img alt="" src={message} />
                                                                    </span>
                                                                </div>
                                                                <input
                                                                    className={`form-control  ${errors?.otp ? 'is-invalid' : ''
                                                                        }`}
                                                                    type="text"
                                                                    name="otp"
                                                                    {...register('otp')}
                                                                    placeholder="Enter Your OTP" />
                                                                <div className="invalid-feedback ">
                                                                    <span style={{ margin: "13px" }}>{errors?.otp?.message}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="text-center mb-4">
                                                            <button className="btn btn-primary fs-16 fw-400" type="submit">Send</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>




                                        </div>
                                        <div className="col-lg-6 text-center d-none d-lg-block">
                                            <img alt="" src={locked_Img} className="img-fluid" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default RegisterOtpPage;

