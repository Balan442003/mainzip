import React from 'react';
import './home.scss';
import Slider from "react-slick";

import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";


import banner1 from '../../assets/images/banner1.png';
import protect1 from '../../assets/images/protect1.png';
import protect2 from '../../assets/images/protect2.png';
import protect3 from '../../assets/images/protect3.png';
import icon1 from '../../assets/images/icon1.png';
import icon2 from '../../assets/images/icon2.png';
import icon3 from '../../assets/images/icon3.png';
import icon4 from '../../assets/images/icon4.png';
import icon5 from '../../assets/images/icon5.png';
import icon6 from '../../assets/images/icon6.png';
import platform1 from '../../assets/images/platform1.png';
import platform2 from '../../assets/images/platform2.png';
import platform3 from '../../assets/images/platform3.png';
import platform4 from '../../assets/images/platform4.png';
import green_sam from '../../assets/images/green_sam.png';
import cryptoPlatform from '../../assets/images/cryptoPlatform.png';

import red_sam from '../../assets/images/red_sam.png';
import mapimg from '../../assets/images/map.png';
import playstore from '../../assets/images/playstore.png';
import appstore from '../../assets/images/appstore.png';
import mob_bg from '../../assets/images/mob_bg.png';



const HomePage = () => {
    const settings = {
        dots: false,
        infinite: true,         
        slidesToShow: 6,
        slidesToScroll: 1,
        initialSlide: 0,
        autoplay: true,        
        autoplaySpeed: 2000,
        speed: 2000,
        cssEase: "linear",
        responsive: [
            {
            breakpoint: 1200,
            settings: {
                slidesToShow: 6,
                slidesToScroll: 1,            
            }
            },
            {
            breakpoint: 900,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                // initialSlide: 2
            }
            },
            {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
            },
            {
                breakpoint: 600,
                settings: {
                slidesToShow: 2,
                slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                slidesToShow: 1,
                slidesToScroll: 1
                }
            }
        ]
      };
      const settings1 = {
        dots: false,
        infinite: true,         
        slidesToShow: 6,
        slidesToScroll: 1,
        initialSlide: 0,
        autoplay: true,        
        autoplaySpeed: 2000,
        speed: 2000,
        cssEase: "linear",
        rtl: true,
        responsive: [
            {
            breakpoint: 1200,
            settings: {
                slidesToShow: 6,
                slidesToScroll: 1,            
            }
            },
            {
            breakpoint: 900,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                // initialSlide: 2
            }
            },
            {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
            },
            {
                breakpoint: 600,
                settings: {
                slidesToShow: 2,
                slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                slidesToShow: 1,
                slidesToScroll: 1
                }
            }
        ]
      };

        return (
            <div className="maincontent homepage">
            <div className="pageContent">
                <div className="container mb-5">
                    <div className="row justify-content-center align-items-center">
                        <div className="col-lg-3">
                            <div className="homebanner_tit65">Let’s Crypto Inversments</div>
                        </div>
                        <div className="col-lg-6">
                            <div className="w-100 position-relative text-center">
                                 <img src={banner1} className="img-fluid" />
                               <div className="text-center" style={{marginTop: "-30px"}}>
                                    <a href="#" className="btn btn-primary">Let’s Started</a>
                                </div>
                            </div>
                            
                        </div>
                        <div className="col-lg-3">
                            <div className="homebanner_tit58">
                                    Buy <br />
                                    Sell <br />
                                    Trade <br />
                                    Exchange
                            </div>
                        </div>
                    </div>
                </div>
                <section className="mb-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="card mycard">
                                    <div className="card-body p-md-5 p-4">
                                            <div className="row">
                                                <div className="col-lg-4 mb-5">
                                                    <div className="fs-36 fw-600">We Secure and
                                                            Protect you</div>
                                                </div>
                                                <div className="col-lg-8 d-flex align-items-center">
                                                    <div className="fs-16 fw-400 lh-24 text-lightblue mb-5">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type</div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                    <div className="col-lg-4">
                                                        <div className="protect_wizard">
                                                            <div className="protect_icon">
                                                                <img src={protect1} />
                                                            </div>
                                                            <div className="protect_tit">Turly Secure</div>
                                                            <div className="protect_cnt">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-4">
                                                            <div className="protect_wizard">
                                                                    <div className="protect_icon">
                                                                        <img src={protect2} />
                                                                    </div>
                                                                    <div className="protect_tit">Instant Trading</div>
                                                                    <div className="protect_cnt">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </div>
                                                                </div>
                                                    </div>
                                                    <div className="col-lg-4">
                                                            <div className="protect_wizard">
                                                                    <div className="protect_icon">
                                                                        <img src={protect3} />
                                                                    </div>
                                                                    <div className="protect_tit">Support</div>
                                                                    <div className="protect_cnt">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </div>
                                                                </div>
                                                    </div>
                                            </div>
                                    </div>                            
                                </div>
                            </div>
                        </div>
                    </div>            
                </section>
        
                <section className="mb-5">
                    <div className="fs-36 fw-600 mb-5 text-center">Our Crypto Inversment</div>
                    
                   <div className="mb-4 mx-4 px-2">
                   <Slider {...settings}>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon1} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon2} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon3} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon4} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon5} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon6} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon1} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon2} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon3} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon4} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon5} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <div>
                                <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon6} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                    </Slider>        
                    </div>
                    <div className="mb-4 mx-4 px-2">
                        <Slider {...settings1}>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon5} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon6} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon1} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon2} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon3} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon4} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>        
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon5} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon6} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon1} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon2} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon3} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">BTC / INR</div>
                                                    <div className="fs-14 fw-500 text-green">9.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="cryptoInvest_box">
                                        <div className="d-flex">
                                            <div>
                                                <img src={icon4} className="img-w40 mr-3" />
                                            </div>
                                            <div className="w-100">
                                                <div className="d-flex justify-content-between">
                                                    <div className="fs-16 fw-500">ETH / INR</div>
                                                    <div className="fs-14 fw-500 text-red">-3.43%</div>
                                                </div>
                                                <div className="fs-14 fw-500 text-gray1">$ 15435.43</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                   
                        </Slider>
                    </div>
                   
                </section>
        
                <section className="mb-5">
                        <div className="fs-36 fw-600 mb-5 text-center">Market Trend</div>
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-12">
                                        <div className="table-responsive">
                                            <table className="table table-borderless mytable">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Last Price</th>
                                                        <th>24h Changes</th>
                                                        <th>Market cap</th>
                                                        <th>Market</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div className="d-flex align-items-center">
                                                                <div>
                                                                    <img src={icon1} className="img-w32 mr-3" />
                                                                </div>
                                                                <div className="d-flex w-100">
                                                                    <div className="w-75">Bitcoin</div>
                                                                    <div className="w-25">BTC</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $ 23,345
                                                        </td>
                                                        <td><span className="text-green">9.43% <i className="bi bi-caret-up-fill"></i></span></td>
                                                        <td>$ 23,345.45</td>
                                                        <td>
                                                            <img src={green_sam} />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div className="d-flex align-items-center">
                                                                <div>
                                                                    <img src={icon2} className="img-w32 mr-3" />
                                                                </div>
                                                                <div className="d-flex w-100">
                                                                    <div className="w-75">Bitcoin</div>
                                                                    <div className="w-25">BTC</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $ 23,345
                                                        </td>
                                                        <td><span className="text-red">-3.43% <i className="bi bi-caret-down-fill"></i></span></td>
                                                        <td>$ 23,345.45</td>
                                                        <td>
                                                            <img src={red_sam} />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div className="d-flex align-items-center">
                                                                <div>
                                                                    <img src={icon1} className="img-w32 mr-3" />
                                                                </div>
                                                                <div className="d-flex w-100">
                                                                    <div className="w-75">Bitcoin</div>
                                                                    <div className="w-25">BTC</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $ 23,345
                                                        </td>
                                                        <td><span className="text-green">9.43% <i className="bi bi-caret-up-fill"></i></span></td>
                                                        <td>$ 23,345.45</td>
                                                        <td>
                                                            <img src={green_sam} />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div className="d-flex align-items-center">
                                                                <div>
                                                                    <img src={icon2} className="img-w32 mr-3" />
                                                                </div>
                                                                <div className="d-flex w-100">
                                                                    <div className="w-75">Bitcoin</div>
                                                                    <div className="w-25">BTC</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $ 23,345
                                                        </td>
                                                        <td><span className="text-red">-3.43% <i className="bi bi-caret-down-fill"></i></span></td>
                                                        <td>$ 23,345.45</td>
                                                        <td>
                                                            <img src={red_sam} />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div className="d-flex align-items-center">
                                                                <div>
                                                                    <img src={icon1} className="img-w32 mr-3" />
                                                                </div>
                                                                <div className="d-flex w-100">
                                                                    <div className="w-75">Bitcoin</div>
                                                                    <div className="w-25">BTC</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $ 23,345
                                                        </td>
                                                        <td><span className="text-green">9.43% <i className="bi bi-caret-up-fill"></i></span></td>
                                                        <td>$ 23,345.45</td>
                                                        <td>
                                                            <img src={green_sam} />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div className="d-flex align-items-center">
                                                                <div>
                                                                    <img src={icon2} className="img-w32 mr-3" />
                                                                </div>
                                                                <div className="d-flex w-100">
                                                                    <div className="w-75">Bitcoin</div>
                                                                    <div className="w-25">BTC</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            $ 23,345
                                                        </td>
                                                        <td><span className="text-red">-3.43% <i className="bi bi-caret-down-fill"></i></span></td>
                                                        <td>$ 23,345.45</td>
                                                        <td>
                                                            <img src={red_sam} />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                </div>
                            </div>
                        </div>
                </section>
        
                <section className="mb-5">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="card mycard">
                                        <div className="card-body p-md-5 p-4">
                                            <div className="row">
                                                <div className="col-lg-5 mb-5">
                                                    <div className="fs-36 fw-600">Most Trused Crypto
                                                            Platform</div>
                                                </div>
                                                <div className="col-lg-7 d-flex align-items-center">
                                                    <div className="fs-16 fw-400 lh-24 text-lightblue mb-5">
                                                            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-lg-5">
                                                    <div className="w-100 text-center">
                                                        <img src={cryptoPlatform} className="img-fluid" />
                                                    </div>
                                                </div>
                                                <div className="col-lg-7">
                                                    <div className="row">
                                                        <div className="col-sm-6">
                                                            <div className="platform_wizard">
                                                                <div className="platform_iconbox1">
                                                                    <div className="platform_icon">
                                                                        <img src={platform1} />
                                                                    </div>
                                                                </div>
                                                                <div className="platform_tit">
                                                                        24/7 support
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-sm-6">
                                                                <div className="platform_wizard">
                                                                    <div className="platform_iconbox1">
                                                                        <div className="platform_icon">
                                                                            <img src={platform2} />
                                                                        </div>
                                                                    </div>
                                                                    <div className="platform_tit">
                                                                            Manage Portfolio
                                                                    </div>
                                                                </div>
                                                            </div>  
                                                            <div className="col-sm-6">
                                                                    <div className="platform_wizard">
                                                                        <div className="platform_iconbox1">
                                                                            <div className="platform_icon">
                                                                                <img src={platform3} />
                                                                            </div>
                                                                        </div>
                                                                        <div className="platform_tit">
                                                                                Live Blogs
                                                                        </div>
                                                                    </div>
                                                                </div>  
                                                                <div className="col-sm-6">
                                                                        <div className="platform_wizard">
                                                                            <div className="platform_iconbox1">
                                                                                <div className="platform_icon">
                                                                                    <img src={platform4} />
                                                                                </div>
                                                                            </div>
                                                                            <div className="platform_tit">
                                                                                    Community
                                                                            </div>
                                                                        </div>
                                                                    </div>                                                
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </section>
        
                <section className="mb-5">                
                        <div className="container">
                                <div className="row">
                                        <div className="col-lg-4 mb-3">
                                            <div className="fs-36 fw-600">Our Best User are a Over the World Wide Coverage</div>
                                        </div>
                                        <div className="col-lg-8 d-flex align-items-center mb-3">
                                            <div className="fs-16 fw-400 lh-24 text-lightblue mb-5">
                                                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                                            </div>
                                        </div>
                                    </div>
                            <div className="row align-items-center">
                                <div className="col-lg-5">
                                    <div className="cvrage_wizard">
                                        <div className="cv_unit">$ 233 M</div>
                                        <div className="cv_type">Quarterly volume traded</div>
                                    </div>
                                    <div className="cvrage_wizard">
                                            <div className="cv_unit">50 +</div>
                                            <div className="cv_type">Countries supported</div>
                                        </div>
                                        <div className="cvrage_wizard">
                                                <div className="cv_unit">13 M+</div>
                                                <div className="cv_type">Verified users</div>
                                            </div>
                                </div>
                                <div className="col-lg-7 pb-5">
                                    <img src={mapimg} className="img-fluid" />
                                </div>
                            </div>
                        </div>
                </section>
        
                <section className="mb-5 pt-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-12">
                                <div className="card mycard">
                                    <div className="card-body p-md-5 p-4">
                                        <div className="row">
                                            <div className="col-lg-7 order-lg-1 order-2">
                                                <div className="fs-36 fw-600 mb-4">Get Ready to Explore the Crypto&nbsp;World</div>
                                                <div className="fs-16 fw-400 lh-24 text-lightblue mb-4">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type</div>
                                                <div>
                                                        <a className="d-inline-block mr-3" href="#">
                                                            <img src={playstore} className="img-fluid" />
                                                        </a>
                                                    <a className="d-inline-block" href="#">
                                                        <img src={appstore} className="img-fluid" />
                                                    </a>
                                                </div>
                                            </div>
                                            <div className="col-lg-5 order-lg-2 order-1 mt-n5">
                                                <div className="mt-n5 mb-n4">
                                                    <img src={mob_bg} className="img-fluid mt-n5" /> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
              
            </div> 
        </div>
        );
    
}
 
export default HomePage;