import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './pages/home';
import Mainlayout from './layout/mainlayout';
import Loginpage from './pages/login';
import Registerpage from './pages/register';
import Forgetpassword from './pages/forgetpassword';
// import Securitycode from './pages/securitycode';

// import Marketpage from './pages/market';
import AppLayout from './layout/applayout';
import Dashboard from './pages/dashboard';
import Profilepage from './pages/profile';
// import BankDetailspage from './pages/bankdetails';
// import Transactionspage from './pages/transactions';
// import Exchangepage from './pages/exchange';
import Securitypage from './pages/security';
// import SupportPage from './pages/support';
import TotalWalletAmt from './pages/Totalwallet';
// import NotFoundoundpage from './pages/notfound';
// import ContactusPage from './pages/contactus';
// import Faqpage from './pages/faq';
import TermsConditionPage from './pages/terms';
import AboutUsPage from './pages/aboutus';
import Changepassword from './pages/changepassword';
import Registerotp from './pages/registerotp'
import ForgetPasswordOtp from './pages/forgetpasswordotp';
import SetNewPassword from './pages/setnewpassword';
import Loginotppage from './pages/loginotp'
import BankDetailspage from './pages/bankdetails';
// import TradePage from './pages/trade';



function App() {


  return (
    <BrowserRouter>
      <>
        <Routes>
          <Route path='/' element={<Mainlayout />}>
            <Route index element={<HomePage />} />
            <Route path="/login" element={<Loginpage />} />
            <Route path="/loginotp" element={<Loginotppage />} />
            <Route path="/register" element={<Registerpage />} />
            <Route path='/registerotp' element={<Registerotp />} />
            <Route path='/forgetpasswordotp' element={<ForgetPasswordOtp />} />
            <Route path='/setnewpassword' element={<SetNewPassword />} />
            {/* <Route path="/securitycode" element={<Securitycode />} /> */}
            <Route path="/forgetpassword" element={<Forgetpassword />} />
            <Route path="/changepassword" element={<Changepassword />} />
            {/* <Route path="/market" element={<Marketpage /> } /> */}
            <Route path='/wallet' element={<TotalWalletAmt />} />
            {/* <Route path='/contactus' element={<ContactusPage/>}/> */}
            {/* <Route path='/faq' element={<Faqpage/>}/> */}
            <Route path='/terms' element={<TermsConditionPage />} />
            <Route path='/aboutus' element={<AboutUsPage />} />
          </Route>

          <Route path='/' element={<AppLayout />}>
            <Route path='/dashboard' element={<Dashboard />} />
            <Route path='/profile' element={<Profilepage />} />
            <Route path='/bank-details' element={<BankDetailspage/>}/>
            {/* <Route path='/transaction' element={<Transactionspage />}/>
        <Route path='/exchange' element={<Exchangepage />}/>  */}
            <Route path='/security' element={<Securitypage />} />
            {/* <Route path='/support' element={<SupportPage />}/> */}
          </Route>
          {/* <Route path='/trade' element={<TradePage/>}/>
      <Route path='/notfound' element={<NotFoundoundpage/>}/> */}
        </Routes>
      </>

    </BrowserRouter>
  );
}

export default App;
