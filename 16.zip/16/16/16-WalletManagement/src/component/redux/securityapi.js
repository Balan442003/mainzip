import { api } from "../service/baseApi";

const securityApi = api.injectEndpoints({
    endpoints: builder => ({
        handleTwofactorAuth: builder.mutation({
            query: (body) => ({
                url: 'security/twoFactorAuthGetSecertKey',
                method: 'POST',
                body
            })
        }),
        twoFactorverifySecretCode: builder.mutation({
            query: (body) => ({
                url: 'security/twoFactorAuthVerifySecret',
                method: 'POST',
                body
            })
        }),
    })
})

export const { useHandleTwofactorAuthMutation, useTwoFactorverifySecretCodeMutation } = securityApi
