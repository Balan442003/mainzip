import { api } from "../service/baseApi"

const forgetPasswordApi = api.injectEndpoints({
    endpoints: builder => ({
        ForgetPassword: builder.mutation({
            query: (body) => ({
                url: 'forgetPassword',
                method: 'POST',
                body
            })
        }),
        ForgetPasswordOtpVerify: builder.mutation({
            query: (body) => ({
                url: 'forgetPassword/forgetpasswordverifyOtp',
                method: 'POST',
                body
            })
        }),
        SetNewPassword: builder.mutation({
            query: (body) => ({
                url: 'forgetPassword/setnewPassword',
                method: 'POST',
                body
            })
        }),
    })
})

export const { useForgetPasswordMutation, useForgetPasswordOtpVerifyMutation , useSetNewPasswordMutation } = forgetPasswordApi
