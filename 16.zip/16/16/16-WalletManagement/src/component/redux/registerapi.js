import { api } from "../service/baseApi"


const getToken = () => {
    return localStorage.getItem('LoggedUserToken');
};


const registerApi = api.injectEndpoints({
    endpoints: builder => ({
        CreateUser: builder.mutation({
            query: (body) => ({
                url: `users/createUsers`,
                method: "POST",
                body
            })
        }),
        RegisterVerifyOtp: builder.mutation({
            query: (body) => ({
                url: `users/userverifyOtp`,
                method: "POST",
                body
            })
        }),
        GetLoginUser: builder.mutation({
            query: (body) => ({
                url: `users/login`,
                method: "POST",
                // headers: {
                //     Authorization: `Bearer ${getToken()}`
                // },
                body
            })
        }),
        LoginVerifyOtp: builder.mutation({
            query: (body) => ({
                url: `users/loginverifyOtp`,
                method: "POST",
                body
            })
        }),
    })
})


export const { useCreateUserMutation, useRegisterVerifyOtpMutation , useGetLoginUserMutation , useLoginVerifyOtpMutation } = registerApi