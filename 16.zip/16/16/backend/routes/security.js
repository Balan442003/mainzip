var express = require('express');
var router = express.Router();
const UserModel = require('../models/userModel')
const securityController = require('../Controllers/securityController')

router.post('/twoFactorAuthGetSecertKey', securityController.handlingTwoFactorAuthentication)
router.post('/twoFactorAuthVerifySecret', securityController.verifyingTwoFactorAuthentication)


module.exports = router;