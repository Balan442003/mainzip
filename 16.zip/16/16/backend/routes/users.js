var express = require('express');
var router = express.Router();
const UserModel = require('../models/userModel')
const userController= require('../Controllers/userControllers')

router.post('/createUsers', userController.createUser)
router.post('/userverifyOtp', userController.verifyOtp)
router.post('/login',userController.login)
router.post('/loginverifyOtp',userController.loginverifyOtp)


module.exports = router;
