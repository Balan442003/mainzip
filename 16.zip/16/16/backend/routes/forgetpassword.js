const express = require('express')
const forgetPasswordControllers = require('../Controllers/forgetpasswordController')
const router = express.Router()

router.post('/', forgetPasswordControllers.handleForgetPassword)
router.post('/forgetpasswordverifyOtp', forgetPasswordControllers.verifyOtp)
router.post('/setnewPassword', forgetPasswordControllers.setNewPassword)

module.exports = router