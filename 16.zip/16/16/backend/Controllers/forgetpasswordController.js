

const UserModel = require('../models/userModel')
const bcrypt = require('bcrypt')

exports.handleForgetPassword = async (req, res) => {
    console.log(req.body);
    try {
        const { email } = req.body
        const getUserData = await UserModel.findOne({ email })
        if (!getUserData) {
            return res.status(401).json({ message: 'User Not Found' })
        }
        const generateOTP = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
        await UserModel.updateOne({ email }, { $set: { 'otp.code': generateOTP } })
        const updateOtpData = await UserModel.findOne({ email })
        res.status(200).json(updateOtpData)
    } catch (err) {
        res.status(500).json({ message: 'Internal Server Error' })
    }

}

exports.verifyOtp = async (req, res) => {
    try {
        const { otp, id } = req.body
        const userData = await UserModel.findOne({ _id: id })
        if (!(otp === userData.otp.code)) {
            return res.status(404).json({ message: 'Your OTP Wrong' })
        } else {
            res.status(200).json({ message: 'OTP Verified' })
        }
    } catch (err) {
        res.status(500).json({ message: "Internal Error" })
    }
}

exports.setNewPassword = async (req, res) => {
    console.log(req.body);
    try {
        const { password, id } = req.body
        const hashPassword = await bcrypt.hash(password, 10)
        await UserModel.updateOne({ _id: id }, { $set: { password: hashPassword } })
        res.status(200).json({ message: 'Password Updated' })
    } catch (err) {
        res.status(500).json({ message: "Internal Error" })
    }
}



