
const UserModel = require('../models/userModel');
const speakEasy = require('@levminer/speakeasy')
const jwt = require('jsonwebtoken')

exports.handlingTwoFactorAuthentication = async (req, res) => {
    try {
        const { id } = req.body
        const secretCode = speakEasy.generateSecret()
        console.log(secretCode);
        await UserModel.updateOne({ _id: id }, { $set: { temp_secret: secretCode } })
        const twoFactorAuthData = await UserModel.findOne({ _id: id })
        res.status(200).json({ message: 'Generate TwoFactorAuth', twoFactorAuthData })

    } catch (error) {
        res.status(500).json({ message: 'Something Went Wrong' })
    }
}

exports.verifyingTwoFactorAuthentication = async (req, res) => {
    try {
        const { id, token } = req.body
        const getUser = await UserModel.findOne({ _id: id })
        const { base32: secret } = getUser.temp_secret
        console.log(getUser.temp_secret);
        let tokenValidates = speakEasy.totp.verify({
            secret,
            encoding: "base32",
            token,
        })
        if (!tokenValidates) {
            return res.status(404).json({ message: 'Authentication Invalid' })
        }
        const jwtToken = jwt.sign(
            { id: getUser._id },
            'sfjkdjkdfdsfjk',
            { expiresIn: '1h' }
        )
        await UserModel.updateOne({ _id: id }, { $set: { temp_secret: null, secret: getUser.temp_secret, twoFactorAuth: true } })
        const updateUser = await UserModel.findOne({ _id: id })
        res.status(200).json({ message: 'Authentication Verified', twoFactorAuth: updateUser.twoFactorAuth, token: jwtToken , id:updateUser._id})

    } catch (error) {
        res.status(500).json({ message: 'Error Generating Authencation ' })
    }
}

