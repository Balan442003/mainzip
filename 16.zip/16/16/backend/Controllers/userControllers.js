const UserModel = require('../models/userModel');
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken");


// Create New USer
exports.createUser = async (req, res) => {

    const exiting = await UserModel.findOne({ email: req.body.email })
    if (exiting) {
        return res.status(409).json({ message: "Already User Exiting" })
    }
    try {
        const { userName, email, password, acceptTerms } = req.body
        const generateOTP = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
        const hashPassword = await bcrypt.hash(password, 10)
        const createUser = {
            userName,
            email,
            password: hashPassword,
            acceptTerms,
            otp: {
                code: generateOTP.toString(),
                // 3minutes Validate
                expiration: new Date(Date.now() + 3 * 60 * 1000),
                verified: false,
            },
        }
        UserModel.create(createUser)
            .then((data) => res.status(201).json({ message: "Register SuccessFully", data }))
            .catch(() => res.status(404).json({ message: "Some Went Wrong" }))
    } catch (err) {
        res.status(500).json({ message: 'Internal Error' })
    }
}

exports.verifyOtp = async (req, res) => {
    try {
        const { otp, id } = req.body
        const userData = await UserModel.findOne({ _id: id })

        if (!(otp === userData.otp.code)) {
            return res.status(404).json({ message: 'Your OTP Wrong' })
        } else {
            await UserModel.updateOne({ _id: id }, { $set: { verified: true } })
            if (userData.verified) {
                res.status(409).json({ message: "User Already Verified" })
            }
            return res.status(200).json({ message: 'OTP Verified' })
        }
    } catch (err) {
        res.status(500).json({ message: "Internal Error" })
    }
}



exports.login = async (req, res) => {

    try {
        const { email, password } = req.body;
        const user = await UserModel.findOne({ email: email });
        console.log(user)
        if (!user) {
            return res.status(400).json({ message: "Login failed, user not found" });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);

        if (!passwordMatch) {
            return res.status(400).json({ message: "Login failed, incorrect password" });
        }

        const generateOTP = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
        await UserModel.updateOne({ email }, { $set: { 'otp.code': generateOTP } })
        const updateOtpData = await UserModel.findOne({ email })
        // // If email and password are valid, create and send a JSON Web Token (JWT)
        // const token = jwt.sign({ _id: user._id }, 'xfgfghfhdsfsdfsfd', { expiresIn: "1hr" });

        res.status(200).json({ updateOtpData });
    } catch (error) {
        console.error("Login failed", error);
        res.status(500).json({ message: "Server error" });
    }
}


exports.loginverifyOtp = async (req, res) => {
    try {
        const { otp, id } = req.body
        const loginData = await UserModel.findOne({ _id: id })
        // If email and password are valid, create and send a JSON Web Token (JWT)
        const token = jwt.sign({ _id: loginData._id }, 'xfgfghfhdsfsdfsfd', { expiresIn: "1hr" });



        if (!(otp === loginData.otp.code)) {
            return res.status(404).json({ message: 'Your OTP Wrong' })
        } else {
            return res.status(200).json({ message: 'OTP Verified',token })
        }
    } catch (err) {
        res.status(500).json({ message: "Internal Error" })
    }
}
