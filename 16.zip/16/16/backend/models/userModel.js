const mongoose = require('mongoose')

const UserSchema = new mongoose.Schema({
    userName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    acceptTerms: {
        type: Boolean,
        required: true
    },
    otp: {
        code: {
            type: String,
            required: true,
        },
        expiration: {
            type: Date,
            required: true,
        },
    },
    createdAt: {
        type: Date,
        default: Date.now(),
    },
    updatedAt: {
        type: Date,
    },
    verified: {
        type: Boolean,
        default: false,
    },
    temp_secret: {
        type: Object
    },
    secret: {
        type: Object,
    },
    twoFactorAuth: {
        type: Boolean,
        default: false
    }
}, {
    collection: 'users',
})

const UserModel = mongoose.model('Users', UserSchema)

module.exports = UserModel